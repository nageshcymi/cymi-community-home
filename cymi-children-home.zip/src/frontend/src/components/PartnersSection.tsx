import { ExternalLink } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { type LocalPartner, getInitialPartners } from "../lib/adminData";

const ACCENT_COLORS = [
  "oklch(42% 0.12 195)",
  "oklch(55% 0.15 150)",
  "oklch(60% 0.14 65)",
  "oklch(50% 0.14 260)",
  "oklch(58% 0.16 30)",
  "oklch(45% 0.13 320)",
];

function PartnerCard({
  partner,
  index,
}: {
  partner: LocalPartner;
  index: number;
}) {
  const accentColor = ACCENT_COLORS[index % ACCENT_COLORS.length];

  return (
    <div
      className="group relative bg-white rounded-2xl border border-[oklch(90%_0.01_80)] shadow-warm flex-shrink-0 w-[260px] p-5 flex flex-col"
      style={{ boxShadow: "0 2px 16px oklch(18% 0.025 60 / 0.07)" }}
    >
      {/* Soft accent glow on hover */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 0%, ${accentColor}08 0%, transparent 70%)`,
        }}
      />

      {/* Avatar / Logo */}
      <div className="flex items-center gap-3 mb-3">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `${accentColor}18` }}
        >
          {partner.logoUrl ? (
            <img
              src={partner.logoUrl}
              alt={partner.name}
              className="w-8 h-8 object-contain rounded-lg"
            />
          ) : (
            <span
              className="font-display font-bold text-base tracking-tight"
              style={{ color: accentColor }}
            >
              {partner.logoInitials}
            </span>
          )}
        </div>

        {/* Name */}
        <h3 className="font-display font-bold text-sm text-[oklch(18%_0.025_60)] leading-tight relative z-10 truncate">
          {partner.name}
        </h3>
      </div>

      {/* Description */}
      <p className="text-[oklch(50%_0.02_60)] text-xs font-body leading-relaxed flex-1 mb-3 relative z-10 line-clamp-2">
        {partner.description}
      </p>

      {/* Visit link */}
      {partner.website && (
        <a
          href={partner.website}
          target="_blank"
          rel="noopener noreferrer"
          className="relative z-10 inline-flex items-center gap-1.5 text-xs font-semibold transition-colors duration-200 mt-auto"
          style={{ color: accentColor }}
          onClick={(e) => e.stopPropagation()}
        >
          Visit Website
          <ExternalLink size={10} />
        </a>
      )}
    </div>
  );
}

export function PartnersSection() {
  const [partners, setPartners] = useState<LocalPartner[]>(getInitialPartners);

  useEffect(() => {
    const handleUpdate = () => {
      setPartners(getInitialPartners());
    };
    window.addEventListener("cymi_partners_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_partners_updated", handleUpdate);
  }, []);

  if (partners.length === 0) return null;

  // Duplicate for seamless infinite loop
  const doubled = [...partners, ...partners];

  return (
    <section
      data-ocid="partners.section"
      className="py-20 sm:py-28 bg-[oklch(97%_0.008_80)] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
            Our Partners
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4">
            Together We Make
            <br />
            <span className="text-[oklch(42%_0.12_195)]">a Difference</span>
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body">
            Organizations working with us to transform children's lives and
            build a brighter future.
          </p>
        </motion.div>
      </div>

      {/* Carousel — overflow visible, no max-width constraint */}
      <div className="relative w-full overflow-hidden">
        {/* Left fade */}
        <div
          className="absolute left-0 top-0 bottom-0 w-24 z-10 pointer-events-none"
          style={{
            background:
              "linear-gradient(to right, oklch(97% 0.008 80), transparent)",
          }}
        />
        {/* Right fade */}
        <div
          className="absolute right-0 top-0 bottom-0 w-24 z-10 pointer-events-none"
          style={{
            background:
              "linear-gradient(to left, oklch(97% 0.008 80), transparent)",
          }}
        />

        {/* Scrolling track */}
        <div
          className="flex gap-5 animate-marquee hover:[animation-play-state:paused] py-4 px-4"
          style={{ width: "max-content" }}
        >
          {doubled.map((partner, i) => (
            <PartnerCard
              key={`${partner.id}-${i}`}
              partner={partner}
              index={i % partners.length}
            />
          ))}
        </div>
      </div>

      {/* Decorative bottom divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-12 h-px bg-gradient-to-r from-transparent via-[oklch(42%_0.12_195_/_0.3)] to-transparent origin-center"
        />
      </div>
    </section>
  );
}
