// Deprecated - replaced by CYMI NGO components
export function ServicesSection() {
  return null;
}
