// Deprecated - replaced by CYMI NGO components
export function WhyUsSection() {
  return null;
}
