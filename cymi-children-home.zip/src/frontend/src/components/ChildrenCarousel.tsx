import { Heart } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { type LocalChild, getInitialChildren } from "../lib/adminData";

// Warm child-friendly accent palette — coral, saffron, lavender, sage, sky, rose
const CHILD_COLORS = [
  {
    bg: "oklch(88% 0.08 28)",
    text: "oklch(40% 0.16 28)",
    badge: "oklch(96% 0.04 28)",
  }, // coral
  {
    bg: "oklch(88% 0.08 75)",
    text: "oklch(40% 0.16 75)",
    badge: "oklch(96% 0.04 75)",
  }, // saffron
  {
    bg: "oklch(87% 0.06 270)",
    text: "oklch(42% 0.12 270)",
    badge: "oklch(96% 0.03 270)",
  }, // lavender
  {
    bg: "oklch(88% 0.07 155)",
    text: "oklch(40% 0.14 155)",
    badge: "oklch(96% 0.04 155)",
  }, // sage
  {
    bg: "oklch(88% 0.07 210)",
    text: "oklch(42% 0.12 210)",
    badge: "oklch(96% 0.04 210)",
  }, // sky
  {
    bg: "oklch(88% 0.08 350)",
    text: "oklch(42% 0.15 350)",
    badge: "oklch(96% 0.04 350)",
  }, // rose
];

const PROGRAM_COLORS: Record<string, string> = {
  "Education Fund 2026": "oklch(42% 0.12 195)",
  "Medical Care & Nutrition": "oklch(48% 0.13 155)",
  "New Dormitory Building": "oklch(55% 0.14 65)",
};

function getProgramColor(program: string): string {
  return PROGRAM_COLORS[program] ?? "oklch(42% 0.12 195)";
}

function ChildCard({
  child,
  index,
}: {
  child: LocalChild;
  index: number;
}) {
  const colors = CHILD_COLORS[index % CHILD_COLORS.length];
  const programColor = getProgramColor(child.program);

  return (
    <article
      className="group relative flex-shrink-0 w-[280px] rounded-3xl overflow-hidden border border-[oklch(90%_0.015_70)] flex flex-col"
      style={{
        background: "oklch(100% 0 0)",
        boxShadow:
          "0 4px 24px oklch(18% 0.025 60 / 0.07), 0 1px 4px oklch(18% 0.025 60 / 0.05)",
      }}
    >
      {/* Warm top band */}
      <div
        className="h-2 w-full flex-shrink-0"
        style={{ background: colors.bg }}
      />

      {/* Photo or initials avatar */}
      <div
        className="mx-auto mt-6 w-20 h-20 rounded-full flex items-center justify-center overflow-hidden flex-shrink-0 ring-4 ring-white shadow-md"
        style={{ background: colors.bg }}
      >
        {child.photoUrl ? (
          <img
            src={child.photoUrl}
            alt={child.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <span
            className="font-display font-black text-2xl tracking-tight select-none"
            style={{ color: colors.text }}
          >
            {child.photoInitials || child.name.slice(0, 2).toUpperCase()}
          </span>
        )}
      </div>

      {/* Content */}
      <div className="px-5 pb-5 pt-4 flex flex-col flex-1">
        {/* Name + age */}
        <div className="text-center mb-2">
          <h3 className="font-display font-black text-lg text-[oklch(18%_0.025_60)] leading-tight">
            {child.name}
          </h3>
          <span
            className="inline-block mt-1 text-xs font-bold rounded-full px-2.5 py-0.5"
            style={{ background: colors.badge, color: colors.text }}
          >
            {child.age}
          </span>
        </div>

        {/* Program badge */}
        <div className="flex justify-center mb-3">
          <span
            className="inline-flex items-center gap-1.5 text-[10px] font-bold rounded-full px-2.5 py-1 tracking-wide uppercase"
            style={{
              background: `${programColor}14`,
              color: programColor,
              border: `1px solid ${programColor}30`,
            }}
          >
            <Heart size={8} />
            {child.program}
          </span>
        </div>

        {/* Story quote */}
        <blockquote className="relative flex-1 pt-3">
          <span
            className="absolute -top-1 left-0 font-display text-5xl leading-none pointer-events-none select-none"
            style={{ color: colors.bg }}
          >
            "
          </span>
          <p className="text-xs font-body text-[oklch(42%_0.02_60)] leading-relaxed line-clamp-4 italic pl-3">
            {child.story}
          </p>
        </blockquote>
      </div>

      {/* Hover glow */}
      <div
        className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 50% 0%, ${colors.bg}40 0%, transparent 65%)`,
        }}
      />
    </article>
  );
}

export function ChildrenCarousel() {
  const [children, setChildren] = useState<LocalChild[]>(getInitialChildren);

  useEffect(() => {
    const handleUpdate = () => {
      setChildren(getInitialChildren());
    };
    window.addEventListener("cymi_children_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_children_updated", handleUpdate);
  }, []);

  if (children.length === 0) return null;

  // Duplicate for seamless infinite loop
  const doubled = [...children, ...children];

  return (
    <section
      data-ocid="children_carousel.section"
      className="py-20 sm:py-28 overflow-hidden"
      style={{
        background:
          "linear-gradient(160deg, oklch(98% 0.01 75) 0%, oklch(96% 0.018 60) 50%, oklch(98% 0.01 80) 100%)",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(55%_0.14_30)] mb-4 px-3 py-1 rounded-full border border-[oklch(55%_0.14_30_/_0.3)] bg-[oklch(55%_0.14_30_/_0.07)]">
            Meet the Children
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4 leading-tight">
            Our Children
            <br />
            <span
              className="font-display"
              style={{
                background:
                  "linear-gradient(135deg, oklch(55% 0.16 28) 0%, oklch(60% 0.14 65) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Fundraising Stories
            </span>
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body leading-relaxed">
            Every child at CYMI has a story worth telling. Your support turns
            their dreams into reality.
          </p>
        </motion.div>
      </div>

      {/* Infinite carousel — full-width */}
      <div className="relative w-full overflow-hidden">
        {/* Left fade */}
        <div
          className="absolute left-0 top-0 bottom-0 w-24 z-10 pointer-events-none"
          style={{
            background:
              "linear-gradient(to right, oklch(97% 0.014 67), transparent)",
          }}
        />
        {/* Right fade */}
        <div
          className="absolute right-0 top-0 bottom-0 w-24 z-10 pointer-events-none"
          style={{
            background:
              "linear-gradient(to left, oklch(97% 0.014 67), transparent)",
          }}
        />

        {/* Scrolling track */}
        <div
          className="flex gap-5 animate-marquee hover:[animation-play-state:paused] py-6 px-4"
          style={{ width: "max-content" }}
        >
          {doubled.map((child, i) => (
            <div
              key={`${child.id}-${i}`}
              data-ocid={
                i < children.length
                  ? `children_carousel.item.${i + 1}`
                  : undefined
              }
            >
              <ChildCard child={child} index={i % children.length} />
            </div>
          ))}
        </div>
      </div>

      {/* Bottom divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-10 h-px origin-center"
          style={{
            background:
              "linear-gradient(to right, transparent, oklch(55% 0.14 28 / 0.3), transparent)",
          }}
        />
      </div>
    </section>
  );
}
