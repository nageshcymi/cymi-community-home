import { Globe, Heart } from "lucide-react";
import { useEffect, useState } from "react";
import { SiFacebook, SiInstagram, SiX, SiYoutube } from "react-icons/si";
import { type SiteContent, getInitialSiteContent } from "../lib/adminData";

interface FooterProps {
  onNavigate: (section: string) => void;
}

const QUICK_LINKS = [
  { label: "Home", section: "home" },
  { label: "About Us", section: "about" },
  { label: "Campaigns", section: "campaigns" },
  { label: "Donate", section: "donate" },
  { label: "Our Impact", section: "impact" },
  { label: "Contact", section: "contact" },
];

const SOCIAL = [
  {
    icon: SiFacebook,
    label: "Facebook",
    href: "https://www.facebook.com/childrenandyouthministryindia/",
    hoverColor: "hover:text-[oklch(65%_0.18_240)]",
  },
  {
    icon: SiYoutube,
    label: "YouTube",
    href: "https://www.youtube.com/@sundayschoolministry8198",
    hoverColor: "hover:text-[oklch(58%_0.22_25)]",
  },
  {
    icon: SiX,
    label: "X / Twitter",
    href: "https://x.com",
    hoverColor: "hover:text-white",
  },
  {
    icon: SiInstagram,
    label: "Instagram",
    href: "https://instagram.com",
    hoverColor: "hover:text-[oklch(68%_0.20_355)]",
  },
  {
    icon: Globe,
    label: "Website",
    href: "https://cymichildrenhome.org",
    hoverColor: "hover:text-[oklch(65%_0.14_195)]",
  },
];

export function Footer({ onNavigate }: FooterProps) {
  const year = new Date().getFullYear();
  const caffeineUrl = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`;
  const [content, setContent] = useState<SiteContent>(getInitialSiteContent);

  useEffect(() => {
    const handleUpdate = () => setContent(getInitialSiteContent());
    window.addEventListener("cymi_site_content_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_site_content_updated", handleUpdate);
  }, []);

  return (
    <footer className="bg-[oklch(18%_0.025_195)] text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <button
              type="button"
              onClick={() => onNavigate("home")}
              className="flex items-center gap-3 mb-4"
            >
              <img
                src="/assets/uploads/bbbb.-2--1.jpg"
                alt="CYMI Logo"
                className="w-10 h-10 object-contain rounded-full"
              />
              <div className="flex flex-col leading-tight">
                <span className="font-display font-bold text-lg text-white">
                  CYMI
                </span>
                <span className="text-xs text-white/60">Children Home</span>
              </div>
            </button>
            <p className="text-white/55 text-sm leading-relaxed mb-6 max-w-xs font-body">
              {content.footerTagline}
            </p>
            {/* Social */}
            <div className="flex flex-wrap gap-2">
              {SOCIAL.map((s) => {
                const Icon = s.icon;
                return (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={s.label}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-ocid={`footer.social.${s.label.toLowerCase().split(" ")[0]}.link`}
                    className={`w-9 h-9 rounded-lg flex items-center justify-center border border-white/15 text-white/40 ${s.hoverColor} hover:border-white/30 hover:bg-white/10 transition-all duration-200 bg-white/5`}
                  >
                    <Icon size={15} />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-display font-bold text-xs tracking-widest uppercase text-white/40 mb-5">
              Quick Links
            </h4>
            <ul className="flex flex-col gap-2.5">
              {QUICK_LINKS.map((link) => (
                <li key={link.section}>
                  <button
                    type="button"
                    onClick={() => onNavigate(link.section)}
                    className="text-sm text-white/55 hover:text-white transition-colors duration-150 text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h4 className="font-display font-bold text-xs tracking-widest uppercase text-white/40 mb-5">
              Contact Us
            </h4>
            <div className="flex flex-col gap-3 text-sm text-white/55 font-body">
              <div>
                <div className="text-xs text-white/30 mb-0.5">Email</div>
                <span>{content.contactEmail}</span>
              </div>
              <div>
                <div className="text-xs text-white/30 mb-0.5">Phone</div>
                <span>{content.contactPhone}</span>
              </div>
              <div>
                <div className="text-xs text-white/30 mb-0.5">Location</div>
                <span>{content.contactAddress}</span>
              </div>
              <div className="mt-2 px-3 py-2 rounded-lg bg-white/8 border border-white/12 text-xs text-white/45">
                {content.footerNgoNote}
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/30">
            © {year} CYMI Children Home. All Rights Reserved.
          </p>
          <p className="text-xs text-white/25 flex items-center gap-1">
            Built with{" "}
            <Heart size={10} className="fill-current text-red-400/60" /> using{" "}
            <a
              href={caffeineUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-2 hover:text-white/50 transition-colors"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
