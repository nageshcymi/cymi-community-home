import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Loader2, Shield } from "lucide-react";
import { useState } from "react";
import { useAdminAuth } from "../hooks/useAdminAuth";

interface AdminLoginModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function AdminLoginModal({
  open,
  onClose,
  onSuccess,
}: AdminLoginModalProps) {
  const { login } = useAdminAuth();
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Simulate a brief loading state for UX polish
    setTimeout(() => {
      const success = login(loginId, password);
      setIsLoading(false);
      if (success) {
        setLoginId("");
        setPassword("");
        setError("");
        onSuccess();
        onClose();
      } else {
        setError("Invalid credentials");
      }
    }, 400);
  };

  const handleClose = () => {
    setLoginId("");
    setPassword("");
    setError("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent
        className="sm:max-w-sm bg-white border border-[oklch(90%_0.01_80)] shadow-xl"
        data-ocid="admin_login.dialog"
      >
        <DialogHeader className="text-center pb-2">
          <div className="flex justify-center mb-3">
            <div className="w-12 h-12 rounded-full bg-[oklch(42%_0.12_195_/_0.1)] flex items-center justify-center">
              <Shield size={22} className="text-[oklch(42%_0.12_195)]" />
            </div>
          </div>
          <DialogTitle className="font-display font-bold text-xl text-[oklch(18%_0.025_60)] text-center">
            Admin Login
          </DialogTitle>
          <DialogDescription className="text-[oklch(50%_0.02_60)] font-body text-sm text-center">
            Enter your credentials to access the admin dashboard.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <Label
              htmlFor="admin-login-id"
              className="text-sm font-medium text-[oklch(30%_0.025_60)]"
            >
              Login ID
            </Label>
            <Input
              id="admin-login-id"
              type="text"
              value={loginId}
              onChange={(e) => {
                setLoginId(e.target.value);
                setError("");
              }}
              placeholder="Enter your login ID"
              autoComplete="username"
              data-ocid="admin_login.id.input"
              className="border-[oklch(88%_0.01_80)] focus:border-[oklch(42%_0.12_195)] focus:ring-[oklch(42%_0.12_195_/_0.2)]"
            />
          </div>

          <div className="space-y-1.5">
            <Label
              htmlFor="admin-password"
              className="text-sm font-medium text-[oklch(30%_0.025_60)]"
            >
              Password
            </Label>
            <div className="relative">
              <Input
                id="admin-password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                placeholder="Enter your password"
                autoComplete="current-password"
                data-ocid="admin_login.password.input"
                className="border-[oklch(88%_0.01_80)] focus:border-[oklch(42%_0.12_195)] focus:ring-[oklch(42%_0.12_195_/_0.2)] pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[oklch(55%_0.02_60)] hover:text-[oklch(35%_0.025_60)] transition-colors"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <p
              data-ocid="admin_login.error_state"
              className="text-sm text-destructive font-medium flex items-center gap-1.5"
              role="alert"
            >
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-destructive flex-shrink-0" />
              {error}
            </p>
          )}

          <Button
            type="submit"
            disabled={isLoading || !loginId || !password}
            data-ocid="admin_login.submit_button"
            className="w-full bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white font-semibold rounded-lg transition-all duration-200 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 size={16} className="mr-2 animate-spin" />
                Verifying...
              </>
            ) : (
              "Login"
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
