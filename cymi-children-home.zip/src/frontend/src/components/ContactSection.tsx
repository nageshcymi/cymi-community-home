import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, Loader2, Mail, MapPin, Phone } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";
import { useSubmitContact } from "../hooks/useQueries";
import { generateId, saveContact } from "../lib/adminData";

interface FormData {
  name: string;
  email: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};
  if (!data.name.trim()) errors.name = "Full name is required";
  if (!data.email.trim()) {
    errors.email = "Email is required";
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = "Please enter a valid email address";
  }
  if (!data.message.trim()) errors.message = "Message is required";
  else if (data.message.trim().length < 10)
    errors.message = "Message must be at least 10 characters";
  return errors;
}

const CONTACT_INFO = [
  { icon: Mail, label: "Email", value: "childrenandyouthministry@gmail.com" },
  { icon: Phone, label: "Phone", value: "+91 9997621079" },
  {
    icon: MapPin,
    label: "Location",
    value: "Bhovi Colony, Jagaluru, Huchangipura, Karnataka 577513, India",
  },
];

export function ContactSection() {
  const [form, setForm] = useState<FormData>({
    name: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const contactMutation = useSubmitContact();

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateForm(form);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      const firstErrorField = Object.keys(validationErrors)[0];
      const el = document.querySelector(
        `[name="${firstErrorField}"]`,
      ) as HTMLElement;
      if (el) el.focus();
      return;
    }

    // Save to localStorage for admin dashboard visibility
    saveContact({
      id: generateId(),
      name: form.name.trim(),
      email: form.email.trim(),
      message: form.message.trim(),
      timestamp: Date.now(),
    });

    try {
      await contactMutation.mutateAsync({
        name: form.name.trim(),
        email: form.email.trim(),
        message: form.message.trim(),
      });
      setSubmitted(true);
      setForm({ name: "", email: "", message: "" });
      setErrors({});
      toast.success("Message received! We'll be in touch soon.");
    } catch {
      // Backend call may fail but local save succeeded
      setSubmitted(true);
      setForm({ name: "", email: "", message: "" });
      setErrors({});
      toast.success("Message received! We'll be in touch soon.");
    }
  };

  return (
    <section id="contact" className="py-24 sm:py-32 bg-[oklch(97%_0.008_80)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
            Get in Touch
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4 section-title section-title-center">
            Contact Us
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body">
            Questions about our programs, volunteering, or partnerships? We
            would love to hear from you.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16 items-start">
          {/* Contact info */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2 flex flex-col gap-8"
          >
            <div>
              <h3 className="font-display font-bold text-xl text-[oklch(18%_0.025_60)] mb-2">
                Reach Out to CYMI
              </h3>
              <p className="text-[oklch(45%_0.02_60)] text-sm leading-relaxed font-body">
                Our team responds to all enquiries within 24 business hours.
                Whether you want to donate, volunteer, sponsor, or simply learn
                more — we are here to help.
              </p>
            </div>

            <div className="flex flex-col gap-4">
              {CONTACT_INFO.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 bg-[oklch(42%_0.12_195_/_0.1)] border border-[oklch(42%_0.12_195_/_0.2)]">
                      <Icon size={16} className="text-[oklch(42%_0.12_195)]" />
                    </div>
                    <div>
                      <div className="text-xs text-[oklch(55%_0.02_60)] font-medium">
                        {item.label}
                      </div>
                      <div className="text-sm font-semibold text-[oklch(25%_0.025_60)]">
                        {item.value}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* NGO notice */}
            <div className="rounded-xl p-5 border border-[oklch(42%_0.12_195_/_0.2)] bg-[oklch(42%_0.12_195_/_0.05)]">
              <div className="text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-2">
                Registered NGO
              </div>
              <p className="text-sm text-[oklch(40%_0.02_60)] leading-relaxed font-body">
                CYMI Children Home is a duly registered Non-Governmental
                Organisation in Kenya. All donations are used directly for child
                welfare programs.
              </p>
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="lg:col-span-3"
          >
            {/* Success */}
            {submitted && (
              <div
                data-ocid="contact.success_state"
                className="rounded-2xl p-10 text-center border border-[oklch(42%_0.12_195_/_0.25)] bg-white flex flex-col items-center gap-4"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                >
                  <CheckCircle
                    size={48}
                    className="text-[oklch(42%_0.12_195)]"
                  />
                </motion.div>
                <h3 className="font-display font-bold text-xl text-[oklch(18%_0.025_60)]">
                  Message Sent!
                </h3>
                <p className="text-[oklch(45%_0.02_60)] text-sm max-w-sm font-body">
                  Thank you for reaching out. Our team will respond within 24
                  business hours.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="mt-2 border-[oklch(42%_0.12_195_/_0.4)] text-[oklch(42%_0.12_195)] hover:bg-[oklch(42%_0.12_195_/_0.06)]"
                  onClick={() => setSubmitted(false)}
                >
                  Send Another Message
                </Button>
              </div>
            )}

            {!submitted && (
              <form
                onSubmit={handleSubmit}
                noValidate
                className="rounded-2xl p-6 sm:p-8 border border-[oklch(90%_0.01_80)] bg-white flex flex-col gap-5 shadow-warm"
              >
                {/* Error state */}
                {contactMutation.isError && (
                  <div
                    data-ocid="contact.error_state"
                    className="rounded-lg p-4 border border-destructive/30 bg-destructive/10 text-sm text-destructive"
                  >
                    Submission failed. Please try again.
                  </div>
                )}

                {/* Name */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="name"
                    className="text-xs font-semibold tracking-wide text-[oklch(35%_0.025_60)]"
                  >
                    Full Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    data-ocid="contact.name.input"
                    type="text"
                    placeholder="Jane Doe"
                    autoComplete="name"
                    value={form.name}
                    onChange={handleChange}
                    className={`border-border focus:border-[oklch(42%_0.12_195_/_0.5)] ${
                      errors.name ? "border-destructive/60" : ""
                    }`}
                  />
                  {errors.name && (
                    <span className="text-xs text-destructive" role="alert">
                      {errors.name}
                    </span>
                  )}
                </div>

                {/* Email */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="contact-email"
                    className="text-xs font-semibold tracking-wide text-[oklch(35%_0.025_60)]"
                  >
                    Email Address <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="contact-email"
                    name="email"
                    data-ocid="contact.email.input"
                    type="email"
                    placeholder="jane@example.com"
                    autoComplete="email"
                    value={form.email}
                    onChange={handleChange}
                    className={`border-border focus:border-[oklch(42%_0.12_195_/_0.5)] ${
                      errors.email ? "border-destructive/60" : ""
                    }`}
                  />
                  {errors.email && (
                    <span className="text-xs text-destructive" role="alert">
                      {errors.email}
                    </span>
                  )}
                </div>

                {/* Message */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="contact-message"
                    className="text-xs font-semibold tracking-wide text-[oklch(35%_0.025_60)]"
                  >
                    Message <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    id="contact-message"
                    name="message"
                    data-ocid="contact.message.textarea"
                    placeholder="I would like to learn more about volunteering at CYMI..."
                    rows={5}
                    value={form.message}
                    onChange={handleChange}
                    className={`border-border focus:border-[oklch(42%_0.12_195_/_0.5)] resize-none font-body ${
                      errors.message ? "border-destructive/60" : ""
                    }`}
                  />
                  {errors.message && (
                    <span className="text-xs text-destructive" role="alert">
                      {errors.message}
                    </span>
                  )}
                </div>

                {/* Submit */}
                <Button
                  type="submit"
                  data-ocid="contact.submit_button"
                  size="lg"
                  disabled={contactMutation.isPending}
                  className="w-full font-bold py-6 rounded-xl bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white transition-all duration-300"
                >
                  {contactMutation.isPending ? (
                    <>
                      <Loader2
                        data-ocid="contact.loading_state"
                        className="mr-2 h-4 w-4 animate-spin"
                      />
                      Sending...
                    </>
                  ) : (
                    "Send Message"
                  )}
                </Button>

                <p className="text-center text-xs text-[oklch(55%_0.02_60)] font-body">
                  We respect your privacy and will never share your information.
                </p>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
