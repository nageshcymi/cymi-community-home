// Deprecated - replaced by CYMI NGO components
export function StatsBar() {
  return null;
}
