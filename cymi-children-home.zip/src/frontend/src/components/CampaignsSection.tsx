import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, Heart, Loader2 } from "lucide-react";
import { motion } from "motion/react";
import { useCampaignProgress, useCampaigns } from "../hooks/useQueries";

interface CampaignsSectionProps {
  onDonate: (campaignId?: bigint) => void;
}

// Fallback campaigns shown while loading or if backend has no data
const FALLBACK_CAMPAIGNS = [
  {
    id: 1n,
    name: "Education Fund 2026",
    description:
      "Fund school fees, uniforms, books, and learning materials for 150 children to ensure they receive quality primary and secondary education.",
    goalAmount: 1500000n, // $15,000 in cents
  },
  {
    id: 2n,
    name: "Medical Care & Nutrition",
    description:
      "Provide comprehensive medical check-ups, vaccinations, dental care, and three balanced meals every day for every child in our home.",
    goalAmount: 2500000n, // $25,000
  },
  {
    id: 3n,
    name: "New Dormitory Building",
    description:
      "Construct a new dormitory to accommodate 50 more children currently on our waiting list, giving them a safe place to call home.",
    goalAmount: 5000000n, // $50,000
  },
];

const FALLBACK_PROGRESS = [
  {
    campaignId: 1n,
    campaignName: "Education Fund 2026",
    totalRaised: 920000n,
    goalAmount: 1500000n,
  },
  {
    campaignId: 2n,
    campaignName: "Medical Care & Nutrition",
    totalRaised: 1800000n,
    goalAmount: 2500000n,
  },
  {
    campaignId: 3n,
    campaignName: "New Dormitory Building",
    totalRaised: 1250000n,
    goalAmount: 5000000n,
  },
];

function centsToDollars(cents: bigint): string {
  const dollars = Number(cents) / 100;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(dollars);
}

function getProgress(raised: bigint, goal: bigint): number {
  if (goal === 0n) return 0;
  const pct = (Number(raised) / Number(goal)) * 100;
  return Math.min(Math.round(pct), 100);
}

export function CampaignsSection({ onDonate }: CampaignsSectionProps) {
  const campaignsQuery = useCampaigns();
  const progressQuery = useCampaignProgress();

  const isLoading = campaignsQuery.isLoading || progressQuery.isLoading;
  const isError = campaignsQuery.isError || progressQuery.isError;

  const campaigns =
    campaignsQuery.data && campaignsQuery.data.length > 0
      ? campaignsQuery.data
      : FALLBACK_CAMPAIGNS;

  const progressMap = new Map<string, bigint>();
  const progressData =
    progressQuery.data && progressQuery.data.length > 0
      ? progressQuery.data
      : FALLBACK_PROGRESS;

  for (const p of progressData) {
    progressMap.set(String(p.campaignId), p.totalRaised);
  }

  return (
    <section id="campaigns" className="py-24 sm:py-32 section-warm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
            Active Campaigns
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4 section-title section-title-center">
            Support Our Programs
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body">
            Every contribution, large or small, directly impacts a child's life.
            Choose a campaign to support below.
          </p>
        </motion.div>

        {/* Loading */}
        {isLoading && (
          <div
            data-ocid="campaigns.loading_state"
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-2xl bg-white p-6 space-y-4">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-3 w-full rounded-full" />
                <Skeleton className="h-10 w-full rounded-full" />
              </div>
            ))}
          </div>
        )}

        {/* Error */}
        {isError && !isLoading && (
          <div
            data-ocid="campaigns.error_state"
            className="flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive max-w-xl mx-auto"
          >
            <AlertCircle size={18} />
            <span className="text-sm">
              Could not load campaigns. Showing example campaigns.
            </span>
          </div>
        )}

        {/* Campaign cards */}
        {!isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {campaigns.slice(0, 3).map((campaign, i) => {
              const raised = progressMap.get(String(campaign.id)) ?? 0n;
              const pct = getProgress(raised, campaign.goalAmount);

              return (
                <motion.div
                  key={String(campaign.id)}
                  data-ocid={`campaigns.item.${i + 1}`}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.12 }}
                  className="card-warm-hover bg-white rounded-2xl overflow-hidden shadow-warm border border-[oklch(90%_0.01_80)]"
                >
                  {/* Campaign header color strip */}
                  <div
                    className="h-2"
                    style={{
                      background:
                        i === 0
                          ? "linear-gradient(90deg, oklch(42% 0.12 195), oklch(55% 0.11 195))"
                          : i === 1
                            ? "linear-gradient(90deg, oklch(75% 0.16 75), oklch(65% 0.14 55))"
                            : "linear-gradient(90deg, oklch(60% 0.15 150), oklch(50% 0.14 160))",
                    }}
                  />

                  <div className="p-6">
                    {/* Campaign name */}
                    <h3 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)] mb-3">
                      {campaign.name}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-[oklch(45%_0.02_60)] leading-relaxed mb-6 font-body min-h-[4rem]">
                      {campaign.description}
                    </p>

                    {/* Progress */}
                    <div className="mb-2 flex justify-between items-center text-sm">
                      <span className="font-semibold text-[oklch(18%_0.025_60)]">
                        {centsToDollars(raised)} raised
                      </span>
                      <span className="text-[oklch(50%_0.02_60)]">{pct}%</span>
                    </div>
                    <Progress
                      value={pct}
                      className="h-2.5 mb-2 bg-[oklch(92%_0.01_80)]"
                      style={
                        {
                          "--progress-foreground":
                            i === 0
                              ? "oklch(42% 0.12 195)"
                              : i === 1
                                ? "oklch(60% 0.14 65)"
                                : "oklch(55% 0.15 150)",
                        } as React.CSSProperties
                      }
                    />
                    <div className="text-xs text-[oklch(55%_0.02_60)] mb-5 font-body">
                      Goal: {centsToDollars(campaign.goalAmount)}
                    </div>

                    {/* Donate button */}
                    <Button
                      type="button"
                      data-ocid={`campaigns.donate.button.${i + 1}`}
                      onClick={() => onDonate(campaign.id)}
                      className="w-full bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-full font-semibold transition-all duration-200"
                    >
                      <Heart size={14} className="mr-2 fill-current" />
                      Donate to This Campaign
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
