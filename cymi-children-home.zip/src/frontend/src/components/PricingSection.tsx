// Deprecated - replaced by CYMI NGO components
export function PricingSection() {
  return null;
}
