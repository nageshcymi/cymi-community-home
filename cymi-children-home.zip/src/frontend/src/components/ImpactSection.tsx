import { BookOpen, Heart, Home, Loader2, Users } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { useStats } from "../hooks/useQueries";
import { type SiteContent, getInitialSiteContent } from "../lib/adminData";

function useCountUp(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start || target === 0) return;
    const startTime = Date.now();
    const endTime = startTime + duration;
    const tick = () => {
      const now = Date.now();
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - (1 - progress) ** 3; // ease out cubic
      setCount(Math.floor(eased * target));
      if (now < endTime) requestAnimationFrame(tick);
      else setCount(target);
    };
    requestAnimationFrame(tick);
  }, [target, duration, start]);
  return count;
}

interface StatCardProps {
  icon: React.ElementType;
  value: number;
  label: string;
  prefix?: string;
  suffix?: string;
  color: string;
  delay: number;
  animate: boolean;
}

function StatCard({
  icon: Icon,
  value,
  label,
  prefix = "",
  suffix = "",
  color,
  delay,
  animate,
}: StatCardProps) {
  const count = useCountUp(value, 2200, animate);
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="stat-glow bg-white rounded-2xl p-8 text-center border border-[oklch(90%_0.01_80)] card-warm-hover"
    >
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
        style={{ background: `${color}18` }}
      >
        <Icon size={26} style={{ color }} />
      </div>
      <div
        className="font-display font-bold text-4xl sm:text-5xl mb-2"
        style={{
          background: `linear-gradient(135deg, ${color} 0%, oklch(75% 0.16 75) 100%)`,
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        {prefix}
        {count.toLocaleString()}
        {suffix}
      </div>
      <div className="text-sm font-semibold text-[oklch(45%_0.02_60)] font-body uppercase tracking-wide">
        {label}
      </div>
    </motion.div>
  );
}

export function ImpactSection() {
  const { data: stats, isLoading } = useStats();
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [content, setContent] = useState<SiteContent>(getInitialSiteContent);

  useEffect(() => {
    const handleUpdate = () => setContent(getInitialSiteContent());
    window.addEventListener("cymi_site_content_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_site_content_updated", handleUpdate);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHasAnimated(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 },
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const totalDonations = stats ? Number(stats.totalDonations) : 0;
  const totalRaised = stats
    ? Math.round(Number(stats.totalAmountRaised) / 100)
    : 0;

  const statItems = [
    {
      icon: Heart,
      value: totalDonations > 0 ? totalDonations : 847,
      label: "Total Donations",
      suffix: "+",
      color: "oklch(55% 0.22 20)",
    },
    {
      icon: Users,
      value: 150,
      label: "Children in Our Care",
      suffix: "+",
      color: "oklch(42% 0.12 195)",
    },
    {
      icon: Home,
      value: totalRaised > 0 ? totalRaised : 128750,
      label: "USD Raised",
      prefix: "$",
      color: "oklch(60% 0.14 65)",
    },
    {
      icon: BookOpen,
      value: 95,
      label: "Graduate to Higher Education",
      suffix: "%",
      color: "oklch(55% 0.15 150)",
    },
  ];

  return (
    <section id="impact" className="py-24 sm:py-32 bg-[oklch(97%_0.008_80)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
            Our Impact
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4 section-title section-title-center">
            Numbers That Matter
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body">
            Every donation you make is tracked, reported, and turned into
            tangible change in the lives of real children.
          </p>
        </motion.div>

        {/* Stats grid */}
        {isLoading ? (
          <div
            data-ocid="impact.loading_state"
            className="flex items-center justify-center py-16"
          >
            <Loader2
              size={32}
              className="animate-spin text-[oklch(42%_0.12_195)]"
            />
          </div>
        ) : (
          <div
            ref={ref}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {statItems.map((item, i) => (
              <StatCard
                key={item.label}
                icon={item.icon}
                value={item.value}
                label={item.label}
                prefix={item.prefix}
                suffix={item.suffix}
                color={item.color}
                delay={i * 0.1}
                animate={hasAnimated}
              />
            ))}
          </div>
        )}

        {/* Testimonial stripe */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 rounded-2xl bg-[oklch(42%_0.12_195)] p-8 sm:p-10 text-center text-white relative overflow-hidden"
        >
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage:
                "radial-gradient(circle at 30% 50%, oklch(75% 0.16 75) 0%, transparent 60%)",
            }}
          />
          <div className="relative z-10">
            <p className="font-display text-xl sm:text-2xl font-bold text-white mb-3">
              {content.impactQuote}
            </p>
            <p className="text-white/70 text-sm font-body">
              {content.impactQuoteAuthor}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
