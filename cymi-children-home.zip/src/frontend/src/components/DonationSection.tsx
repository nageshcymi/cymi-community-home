import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Check,
  CheckCircle,
  Copy,
  Heart,
  Loader2,
  Lock,
  Smartphone,
} from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useCampaigns, useSubmitDonation } from "../hooks/useQueries";
import { generateId, saveDonation } from "../lib/adminData";

const UPI_ID = "nageshcymi@ikwik";
const BANK_DETAILS = {
  accountName: "Children and Youth Ministry India",
  bankName: "Your Bank Name",
  accountNumber: "XXXXXXXXXXXX",
  ifscCode: "XXXXXXXXX",
  branch: "Jagaluru, Karnataka",
};

interface DonationSectionProps {
  preselectedCampaignId?: bigint;
}

const PRESET_AMOUNTS = [10, 25, 50, 100, 250];

// Fallback campaigns for when backend data is unavailable
const FALLBACK_CAMPAIGNS = [
  {
    id: 1n,
    name: "Education Fund 2026",
    description: "",
    goalAmount: 1500000n,
  },
  {
    id: 2n,
    name: "Medical Care & Nutrition",
    description: "",
    goalAmount: 2500000n,
  },
  {
    id: 3n,
    name: "New Dormitory Building",
    description: "",
    goalAmount: 5000000n,
  },
];

interface FormErrors {
  name?: string;
  email?: string;
  customAmount?: string;
}

function validateEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function DonationSection({
  preselectedCampaignId,
}: DonationSectionProps) {
  const [selectedAmount, setSelectedAmount] = useState<number | "custom">(25);
  const [customAmount, setCustomAmount] = useState("");
  const [donorName, setDonorName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [campaignId, setCampaignId] = useState<string>("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState(false);

  const handleCopyUpi = async () => {
    await navigator.clipboard.writeText(UPI_ID);
    setCopiedUpi(true);
    toast.success("UPI ID copied!");
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleCopyAccount = async () => {
    await navigator.clipboard.writeText(BANK_DETAILS.accountNumber);
    setCopiedAccount(true);
    toast.success("Account number copied!");
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const { data: campaigns } = useCampaigns();
  const donationMutation = useSubmitDonation();

  const availableCampaigns =
    campaigns && campaigns.length > 0 ? campaigns : FALLBACK_CAMPAIGNS;

  // Pre-select campaign from prop
  useEffect(() => {
    if (preselectedCampaignId !== undefined) {
      setCampaignId(String(preselectedCampaignId));
    }
  }, [preselectedCampaignId]);

  // Default to first campaign if none selected
  useEffect(() => {
    if (!campaignId && availableCampaigns.length > 0) {
      setCampaignId(String(availableCampaigns[0].id));
    }
  }, [availableCampaigns, campaignId]);

  const getAmountValue = (): number | null => {
    if (selectedAmount === "custom") {
      const val = Number.parseFloat(customAmount);
      return Number.isNaN(val) || val <= 0 ? null : val;
    }
    return selectedAmount;
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!donorName.trim()) newErrors.name = "Full name is required";
    if (!email.trim()) {
      newErrors.email = "Email is required";
    } else if (!validateEmail(email)) {
      newErrors.email = "Please enter a valid email";
    }
    if (selectedAmount === "custom") {
      const val = Number.parseFloat(customAmount);
      if (!customAmount || Number.isNaN(val) || val <= 0) {
        newErrors.customAmount = "Please enter a valid amount";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const amount = getAmountValue();
    if (!amount) return;

    const amountInCents = BigInt(Math.round(amount * 100));
    const selectedCampaignId = BigInt(campaignId || "1");

    // Save to localStorage for admin dashboard visibility
    saveDonation({
      id: generateId(),
      donorName: donorName.trim(),
      email: email.trim(),
      amount: Number(amountInCents),
      campaignId: Number(selectedCampaignId),
      message: message.trim(),
      timestamp: Date.now(),
    });

    try {
      await donationMutation.mutateAsync({
        donorName: donorName.trim(),
        email: email.trim(),
        amount: amountInCents,
        message: message.trim(),
        campaignId: selectedCampaignId,
      });
      setSubmitted(true);
      toast.success("Thank you for your generous donation! 🙏");
    } catch {
      // Backend call may fail but local save succeeded
      setSubmitted(true);
      toast.success("Thank you for your generous donation! 🙏");
    }
  };

  if (submitted) {
    return (
      <section id="donate" className="py-24 sm:py-32 bg-[oklch(42%_0.12_195)]">
        <div className="max-w-xl mx-auto px-4 sm:px-6 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            data-ocid="donation.success_state"
            className="bg-white rounded-3xl p-10 shadow-warm-lg flex flex-col items-center gap-5"
          >
            <div className="w-20 h-20 rounded-full bg-[oklch(42%_0.12_195_/_0.1)] flex items-center justify-center">
              <CheckCircle size={40} className="text-[oklch(42%_0.12_195)]" />
            </div>
            <h3 className="font-display font-bold text-2xl text-[oklch(18%_0.025_60)]">
              Thank You!
            </h3>
            <p className="text-[oklch(45%_0.02_60)] text-base leading-relaxed font-body max-w-sm">
              Your donation has been received. You are making a real difference
              in a child's life. We will send a receipt to{" "}
              <strong>{email}</strong>.
            </p>
            <Button
              type="button"
              onClick={() => {
                setSubmitted(false);
                setDonorName("");
                setEmail("");
                setMessage("");
                setCustomAmount("");
                setSelectedAmount(25);
              }}
              className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-full px-8"
            >
              Make Another Donation
            </Button>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section
      id="donate"
      className="py-24 sm:py-32 bg-[oklch(42%_0.12_195)] relative overflow-hidden"
    >
      {/* Background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 50%, oklch(75% 0.16 75) 0%, transparent 50%), radial-gradient(circle at 80% 50%, oklch(60% 0.1 195) 0%, transparent 50%)",
        }}
      />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(80%_0.14_75)] mb-4 px-3 py-1 rounded-full border border-[oklch(75%_0.16_75_/_0.4)] bg-[oklch(75%_0.16_75_/_0.12)]">
            Make a Difference
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-white mb-4">
            Donate to CYMI
            <br />
            <span
              style={{
                background:
                  "linear-gradient(135deg, oklch(90% 0.14 75) 0%, oklch(80% 0.18 65) 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Children Home
            </span>
          </h2>
          <p className="text-white/75 text-lg max-w-xl mx-auto font-body">
            Your generosity directly provides food, shelter, education, and
            medical care to vulnerable children in Kenya.
          </p>
        </motion.div>

        {/* Form card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="bg-white rounded-3xl shadow-warm-lg overflow-hidden"
        >
          {/* UPI / Bank Transfer Panel */}
          <div className="px-6 sm:px-10 pt-8 pb-6">
            <div className="text-center mb-6">
              <span className="text-xs font-bold tracking-widest uppercase text-[oklch(50%_0.02_60)]">
                Payment Options
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {/* UPI Card */}
              <div
                className="rounded-2xl border p-5 flex flex-col gap-4"
                style={{
                  background:
                    "linear-gradient(135deg, oklch(96% 0.04 170) 0%, oklch(98% 0.02 175) 100%)",
                  borderColor: "oklch(75% 0.12 170 / 0.35)",
                }}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: "oklch(45% 0.14 165)" }}
                  >
                    <Smartphone size={16} className="text-white" />
                  </div>
                  <h3
                    className="font-display font-bold text-base"
                    style={{ color: "oklch(25% 0.08 165)" }}
                  >
                    Pay via UPI
                  </h3>
                </div>

                {/* UPI ID with copy */}
                <div
                  className="flex items-center justify-between gap-2 rounded-xl px-4 py-3 border"
                  style={{
                    background: "oklch(100% 0 0)",
                    borderColor: "oklch(75% 0.12 170 / 0.4)",
                  }}
                >
                  <span
                    className="font-mono text-sm font-semibold truncate"
                    style={{ color: "oklch(30% 0.1 165)" }}
                  >
                    {UPI_ID}
                  </span>
                  <button
                    type="button"
                    data-ocid="donation.upi_copy_button"
                    onClick={handleCopyUpi}
                    className="shrink-0 p-1.5 rounded-lg transition-all duration-200 hover:scale-110"
                    style={{
                      background: copiedUpi
                        ? "oklch(45% 0.14 165)"
                        : "oklch(90% 0.06 170)",
                      color: copiedUpi ? "white" : "oklch(35% 0.1 165)",
                    }}
                    title="Copy UPI ID"
                  >
                    {copiedUpi ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>

                {/* QR Code */}
                <div
                  className="rounded-xl flex flex-col items-center justify-center gap-2 py-4 border"
                  style={{
                    background: "oklch(99% 0.005 165)",
                    borderColor: "oklch(75% 0.12 170 / 0.35)",
                  }}
                >
                  <img
                    src="/assets/uploads/WhatsApp-Image-2026-03-07-at-9.09.03-PM-1.jpeg"
                    alt="UPI QR Code - Scan to pay nageshcymi@ikwik"
                    className="w-44 h-44 object-contain rounded-lg"
                  />
                  <p
                    className="text-xs font-semibold text-center px-2 leading-snug"
                    style={{ color: "oklch(35% 0.08 165)" }}
                  >
                    Scan with any UPI app
                  </p>
                  <p
                    className="text-xs text-center px-3 leading-snug"
                    style={{ color: "oklch(50% 0.05 165)" }}
                  >
                    Google Pay · PhonePe · Paytm · BHIM
                  </p>
                </div>

                <p
                  className="text-xs text-center leading-relaxed font-body"
                  style={{ color: "oklch(40% 0.06 165)" }}
                >
                  After payment, please fill the form below so we can send you a
                  receipt
                </p>
              </div>

              {/* Bank Transfer Card */}
              <div
                className="rounded-2xl border p-5 flex flex-col gap-4"
                style={{
                  background:
                    "linear-gradient(135deg, oklch(97% 0.01 230) 0%, oklch(99% 0.005 230) 100%)",
                  borderColor: "oklch(70% 0.08 230 / 0.35)",
                }}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: "oklch(35% 0.08 230)" }}
                  >
                    <svg
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="w-4 h-4 text-white"
                      aria-hidden="true"
                    >
                      <path d="M2 10v3h2v7h2v-7h4v7h2v-7h4v7h2v-7h2v-3L12 2 2 10zm10-4l6 4H6l6-4z" />
                    </svg>
                  </div>
                  <h3
                    className="font-display font-bold text-base"
                    style={{ color: "oklch(20% 0.04 230)" }}
                  >
                    Bank Transfer
                  </h3>
                  <span
                    className="text-xs font-semibold px-2 py-0.5 rounded-full"
                    style={{
                      background: "oklch(90% 0.05 230)",
                      color: "oklch(35% 0.08 230)",
                    }}
                  >
                    NEFT/RTGS/IMPS
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { label: "Account Name", value: BANK_DETAILS.accountName },
                    { label: "Bank Name", value: BANK_DETAILS.bankName },
                    {
                      label: "Account No.",
                      value: BANK_DETAILS.accountNumber,
                      copyable: true,
                    },
                    { label: "IFSC Code", value: BANK_DETAILS.ifscCode },
                    { label: "Branch", value: BANK_DETAILS.branch },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="flex items-center justify-between gap-2 rounded-lg px-3 py-2 border"
                      style={{
                        background: "oklch(100% 0 0)",
                        borderColor: "oklch(88% 0.03 230)",
                      }}
                    >
                      <div className="flex flex-col min-w-0">
                        <span
                          className="text-xs font-semibold uppercase tracking-wide"
                          style={{ color: "oklch(55% 0.04 230)" }}
                        >
                          {item.label}
                        </span>
                        <span
                          className="text-sm font-semibold truncate font-mono"
                          style={{ color: "oklch(20% 0.03 230)" }}
                        >
                          {item.value}
                        </span>
                      </div>
                      {item.copyable && (
                        <button
                          type="button"
                          data-ocid="donation.bank_copy_button"
                          onClick={handleCopyAccount}
                          className="shrink-0 p-1.5 rounded-lg transition-all duration-200 hover:scale-110"
                          style={{
                            background: copiedAccount
                              ? "oklch(35% 0.08 230)"
                              : "oklch(92% 0.04 230)",
                            color: copiedAccount
                              ? "white"
                              : "oklch(35% 0.08 230)",
                          }}
                          title="Copy account number"
                        >
                          {copiedAccount ? (
                            <Check size={14} />
                          ) : (
                            <Copy size={14} />
                          )}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Divider */}
            <div className="relative flex items-center gap-4">
              <div className="flex-1 h-px bg-[oklch(90%_0.01_80)]" />
              <span className="text-xs font-bold tracking-widest uppercase text-[oklch(60%_0.02_60)] whitespace-nowrap px-2">
                or fill out the form below
              </span>
              <div className="flex-1 h-px bg-[oklch(90%_0.01_80)]" />
            </div>
          </div>

          <form
            onSubmit={handleSubmit}
            noValidate
            className="px-6 sm:px-10 pb-6 sm:pb-10 pt-0"
          >
            {/* Error state */}
            {donationMutation.isError && (
              <div
                data-ocid="donation.error_state"
                className="mb-6 rounded-xl p-4 bg-destructive/10 border border-destructive/25 text-destructive text-sm flex items-center gap-2"
              >
                <span>Something went wrong. Please try again.</span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left column */}
              <div className="flex flex-col gap-6">
                {/* Campaign selector */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="campaign"
                    className="text-sm font-semibold text-[oklch(30%_0.025_60)]"
                  >
                    Select Campaign
                  </Label>
                  <Select value={campaignId} onValueChange={setCampaignId}>
                    <SelectTrigger
                      data-ocid="donation.select"
                      id="campaign"
                      className="border-border focus:ring-[oklch(42%_0.12_195_/_0.3)]"
                    >
                      <SelectValue placeholder="Choose a campaign..." />
                    </SelectTrigger>
                    <SelectContent>
                      {availableCampaigns.map((c) => (
                        <SelectItem key={String(c.id)} value={String(c.id)}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Preset amounts */}
                <div className="flex flex-col gap-2">
                  <Label className="text-sm font-semibold text-[oklch(30%_0.025_60)]">
                    Donation Amount (USD)
                  </Label>
                  <div className="grid grid-cols-3 gap-2">
                    {PRESET_AMOUNTS.map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        data-ocid="donation.amount.button"
                        onClick={() => setSelectedAmount(amt)}
                        className={`py-2.5 px-3 rounded-xl border text-sm font-semibold transition-all duration-200 ${
                          selectedAmount === amt
                            ? "amount-btn-active shadow-warm"
                            : "border-border text-[oklch(40%_0.02_60)] hover:border-[oklch(42%_0.12_195)] hover:text-[oklch(42%_0.12_195)] bg-white"
                        }`}
                      >
                        ${amt}
                      </button>
                    ))}
                    <button
                      type="button"
                      data-ocid="donation.amount.button"
                      onClick={() => setSelectedAmount("custom")}
                      className={`py-2.5 px-3 rounded-xl border text-sm font-semibold transition-all duration-200 ${
                        selectedAmount === "custom"
                          ? "amount-btn-active shadow-warm"
                          : "border-border text-[oklch(40%_0.02_60)] hover:border-[oklch(42%_0.12_195)] hover:text-[oklch(42%_0.12_195)] bg-white"
                      }`}
                    >
                      Custom
                    </button>
                  </div>

                  {/* Custom amount input */}
                  {selectedAmount === "custom" && (
                    <div className="flex flex-col gap-1">
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[oklch(45%_0.02_60)] font-semibold">
                          $
                        </span>
                        <Input
                          type="number"
                          min="1"
                          step="1"
                          data-ocid="donation.input"
                          placeholder="Enter amount"
                          value={customAmount}
                          onChange={(e) => {
                            setCustomAmount(e.target.value);
                            if (errors.customAmount)
                              setErrors((prev) => ({
                                ...prev,
                                customAmount: undefined,
                              }));
                          }}
                          className={`pl-8 border-border focus:border-[oklch(42%_0.12_195_/_0.5)] ${
                            errors.customAmount ? "border-destructive/60" : ""
                          }`}
                        />
                      </div>
                      {errors.customAmount && (
                        <span className="text-xs text-destructive">
                          {errors.customAmount}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Donor Name */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="donorName"
                    className="text-sm font-semibold text-[oklch(30%_0.025_60)]"
                  >
                    Full Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="donorName"
                    type="text"
                    data-ocid="donation.name.input"
                    autoComplete="name"
                    placeholder="Jane Doe"
                    value={donorName}
                    onChange={(e) => {
                      setDonorName(e.target.value);
                      if (errors.name)
                        setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    className={`border-border focus:border-[oklch(42%_0.12_195_/_0.5)] ${
                      errors.name ? "border-destructive/60" : ""
                    }`}
                  />
                  {errors.name && (
                    <span className="text-xs text-destructive">
                      {errors.name}
                    </span>
                  )}
                </div>
              </div>

              {/* Right column */}
              <div className="flex flex-col gap-6">
                {/* Email */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="email"
                    className="text-sm font-semibold text-[oklch(30%_0.025_60)]"
                  >
                    Email Address <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    data-ocid="donation.email.input"
                    autoComplete="email"
                    placeholder="jane@example.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email)
                        setErrors((prev) => ({ ...prev, email: undefined }));
                    }}
                    className={`border-border focus:border-[oklch(42%_0.12_195_/_0.5)] ${
                      errors.email ? "border-destructive/60" : ""
                    }`}
                  />
                  {errors.email && (
                    <span className="text-xs text-destructive">
                      {errors.email}
                    </span>
                  )}
                </div>

                {/* Message */}
                <div className="flex flex-col gap-1.5">
                  <Label
                    htmlFor="message"
                    className="text-sm font-semibold text-[oklch(30%_0.025_60)]"
                  >
                    Message (Optional)
                  </Label>
                  <Textarea
                    id="message"
                    data-ocid="donation.message.textarea"
                    placeholder="Leave an encouraging message for the children..."
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="border-border focus:border-[oklch(42%_0.12_195_/_0.5)] resize-none font-body"
                  />
                </div>

                {/* Donation summary */}
                <div className="rounded-xl bg-[oklch(97%_0.008_80)] border border-[oklch(90%_0.01_80)] p-4">
                  <div className="text-xs font-bold tracking-widest uppercase text-[oklch(50%_0.02_60)] mb-2">
                    Donation Summary
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[oklch(40%_0.02_60)] font-body">
                      Amount:
                    </span>
                    <span className="font-display font-bold text-xl text-[oklch(42%_0.12_195)]">
                      {selectedAmount === "custom"
                        ? customAmount
                          ? `$${Number.parseFloat(customAmount).toFixed(2)}`
                          : "$0.00"
                        : `$${selectedAmount}.00`}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="mt-8 flex flex-col items-center gap-3">
              <Button
                type="submit"
                data-ocid="donation.submit_button"
                size="lg"
                disabled={donationMutation.isPending}
                className="w-full max-w-md bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white font-bold text-base py-6 rounded-full shadow-warm-lg transition-all duration-300"
              >
                {donationMutation.isPending ? (
                  <>
                    <Loader2
                      data-ocid="donation.loading_state"
                      className="mr-2 h-5 w-5 animate-spin"
                    />
                    Processing...
                  </>
                ) : (
                  <>
                    <Heart size={18} className="mr-2 fill-current" />
                    Donate Now
                  </>
                )}
              </Button>
              <div className="flex items-center gap-1.5 text-xs text-[oklch(55%_0.02_60)] font-body">
                <Lock size={12} />
                Secure & encrypted donation
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
