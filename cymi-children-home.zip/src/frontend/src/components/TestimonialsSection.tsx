import { Star } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import {
  type LocalTestimonial,
  getInitialTestimonials,
} from "../lib/adminData";

const ACCENT_COLORS = [
  "oklch(42% 0.12 195)",
  "oklch(60% 0.14 65)",
  "oklch(55% 0.15 150)",
  "oklch(50% 0.14 260)",
  "oklch(58% 0.16 30)",
  "oklch(45% 0.13 320)",
];

export function TestimonialsSection() {
  const [testimonials, setTestimonials] = useState<LocalTestimonial[]>(
    getInitialTestimonials,
  );

  useEffect(() => {
    const handleUpdate = () => {
      setTestimonials(getInitialTestimonials());
    };
    window.addEventListener("cymi_testimonials_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_testimonials_updated", handleUpdate);
  }, []);

  if (testimonials.length === 0) return null;

  return (
    <section className="py-24 sm:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
            Donor Stories
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-4 section-title section-title-center">
            Voices of Impact
          </h2>
          <p className="text-[oklch(45%_0.02_60)] text-lg max-w-2xl mx-auto font-body">
            Hear from the generous people who have chosen to stand with CYMI
            Children Home and the children we serve.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => {
            const accentColor = ACCENT_COLORS[i % ACCENT_COLORS.length];
            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: i * 0.12 }}
                className="card-warm-hover bg-[oklch(97%_0.008_80)] rounded-2xl p-8 border border-[oklch(90%_0.01_80)] relative overflow-hidden flex flex-col"
              >
                {/* Large quote mark */}
                <div
                  className="absolute top-4 right-6 font-display text-[6rem] leading-none select-none opacity-10"
                  style={{ color: accentColor }}
                >
                  "
                </div>

                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }, (_, idx) => (
                    <Star
                      key={`star-${t.id}-${idx}`}
                      size={14}
                      className="fill-[oklch(75%_0.16_75)] text-[oklch(75%_0.16_75)]"
                    />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-[oklch(35%_0.02_60)] leading-relaxed text-sm font-body flex-1 mb-6 relative z-10">
                  "{t.quote}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0"
                    style={{ background: accentColor }}
                  >
                    {t.avatarInitials}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[oklch(18%_0.025_60)]">
                      {t.name}
                    </div>
                    <div className="text-xs text-[oklch(55%_0.02_60)] font-body">
                      {t.role}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
