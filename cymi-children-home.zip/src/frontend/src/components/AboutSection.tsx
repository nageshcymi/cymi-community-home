import { BookOpen, Heart, Home, Shield } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { type SiteContent, getInitialSiteContent } from "../lib/adminData";

const VALUES = [
  {
    icon: Heart,
    label: "Love & Care",
    desc: "Every child receives unconditional love and a nurturing home environment.",
  },
  {
    icon: BookOpen,
    label: "Education",
    desc: "Quality schooling and mentorship programs to unlock each child's potential.",
  },
  {
    icon: Shield,
    label: "Safety & Health",
    desc: "Full medical care, nutrition, and a safe space for all children in our program.",
  },
  {
    icon: Home,
    label: "A Place to Belong",
    desc: "Building community, belonging, and hope for every vulnerable child.",
  },
];

export function AboutSection() {
  const [content, setContent] = useState<SiteContent>(getInitialSiteContent);

  useEffect(() => {
    const handleUpdate = () => setContent(getInitialSiteContent());
    window.addEventListener("cymi_site_content_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_site_content_updated", handleUpdate);
  }, []);

  const STATS = [
    { value: content.childrenCount, label: "Children in Our Care" },
    { value: content.yearsOfService, label: "Years of Service" },
    { value: content.donorsCount, label: "Donors Worldwide" },
    { value: content.graduationRate, label: "Graduate to Higher Education" },
  ];

  return (
    <section id="about" className="py-24 sm:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: Text */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65 }}
          >
            <span className="inline-block text-xs font-bold tracking-widest uppercase text-[oklch(42%_0.12_195)] mb-4 px-3 py-1 rounded-full border border-[oklch(42%_0.12_195_/_0.25)] bg-[oklch(42%_0.12_195_/_0.06)]">
              Our Mission
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[oklch(18%_0.025_60)] mb-6 section-title">
              {content.aboutSubheading.split(",").length > 1 ? (
                <>
                  {content.aboutSubheading.split(",")[0]},
                  <br />
                  <span
                    style={{
                      background:
                        "linear-gradient(135deg, oklch(42% 0.12 195) 0%, oklch(52% 0.11 195) 100%)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    {content.aboutSubheading.split(",").slice(1).join(",")}
                  </span>
                </>
              ) : (
                <span
                  style={{
                    background:
                      "linear-gradient(135deg, oklch(42% 0.12 195) 0%, oklch(52% 0.11 195) 100%)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {content.aboutSubheading}
                </span>
              )}
            </h2>

            {/* Bio */}
            <p className="text-[oklch(38%_0.02_60)] leading-relaxed mb-6 font-body text-base italic border-l-4 border-[oklch(42%_0.12_195_/_0.4)] pl-4 bg-[oklch(97%_0.008_195)] rounded-r-lg py-3 pr-3">
              {content.aboutBio}
            </p>

            <p className="text-[oklch(38%_0.02_60)] leading-relaxed mb-6 font-body text-base">
              {content.aboutStory1}
            </p>
            <p className="text-[oklch(38%_0.02_60)] leading-relaxed mb-8 font-body text-base">
              {content.aboutStory2}
            </p>

            {/* Values grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {VALUES.map((v, i) => {
                const Icon = v.icon;
                return (
                  <motion.div
                    key={v.label}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="flex items-start gap-3 p-4 rounded-xl bg-[oklch(97%_0.008_80)] border border-[oklch(90%_0.01_80)]"
                  >
                    <div className="w-9 h-9 rounded-lg bg-[oklch(42%_0.12_195_/_0.1)] flex items-center justify-center flex-shrink-0">
                      <Icon size={16} className="text-[oklch(42%_0.12_195)]" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[oklch(18%_0.025_60)] mb-0.5">
                        {v.label}
                      </div>
                      <div className="text-xs text-[oklch(50%_0.02_60)] leading-relaxed">
                        {v.desc}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* Right: Stats */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: 0.1 }}
            className="flex flex-col gap-6"
          >
            {/* Image placeholder with warm overlay */}
            <div
              className="relative rounded-2xl overflow-hidden h-64 sm:h-80 shadow-warm-lg"
              style={{
                background:
                  "linear-gradient(135deg, oklch(42% 0.12 195 / 0.15) 0%, oklch(75% 0.16 75 / 0.15) 100%), url('/assets/generated/cymi-hero-bg.dim_1200x600.jpg') center/cover",
              }}
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-4">
                    <Heart size={36} className="text-white fill-current" />
                  </div>
                  <p className="text-white font-display font-bold text-xl">
                    Our Children Are Our Priority
                  </p>
                </div>
              </div>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-2 gap-4">
              {STATS.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="stat-glow rounded-2xl p-6 text-center bg-white border border-[oklch(90%_0.01_80)]"
                >
                  <div
                    className="font-display font-bold text-3xl sm:text-4xl mb-1"
                    style={{
                      background:
                        "linear-gradient(135deg, oklch(42% 0.12 195) 0%, oklch(75% 0.16 75) 100%)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-xs font-medium text-[oklch(50%_0.02_60)] font-body">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
