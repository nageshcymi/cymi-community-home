import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft,
  Baby,
  BookOpen,
  DollarSign,
  Edit2,
  Globe,
  Handshake,
  Heart,
  LayoutDashboard,
  Loader2,
  LogOut,
  Mail,
  MessageSquare,
  Plus,
  Save,
  Shield,
  Star,
  Target,
  Trash2,
  TrendingUp,
  Users,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useAdminAuth } from "../hooks/useAdminAuth";
import {
  LS_CAMPAIGNS,
  LS_CHILDREN,
  LS_CONTACTS,
  LS_DONATIONS,
  LS_PARTNERS,
  LS_SITE_CONTENT,
  LS_TESTIMONIALS,
  type LocalCampaign,
  type LocalChild,
  type LocalContact,
  type LocalDonation,
  type LocalPartner,
  type LocalTestimonial,
  type SiteContent,
  centsToDollars,
  formatDate,
  generateId,
  getInitialCampaigns,
  getInitialChildren,
  getInitialContacts,
  getInitialDonations,
  getInitialPartners,
  getInitialSiteContent,
  getInitialTestimonials,
} from "../lib/adminData";

interface AdminDashboardProps {
  onBack: () => void;
}

// ── Overview Tab ────────────────────────────────────────────

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <Card className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl">
      <CardContent className="p-5 flex items-center gap-4">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `${color}18` }}
        >
          <Icon size={22} style={{ color }} />
        </div>
        <div>
          <div className="text-2xl font-display font-bold text-[oklch(18%_0.025_60)]">
            {value}
          </div>
          <div className="text-xs text-[oklch(55%_0.02_60)] font-body mt-0.5">
            {label}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function OverviewTab({
  donations,
  contacts,
  campaigns,
}: {
  donations: LocalDonation[];
  contacts: LocalContact[];
  campaigns: LocalCampaign[];
}) {
  const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);
  const recent5Donations = [...donations]
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 5);
  const recent5Contacts = [...contacts]
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Heart}
          label="Total Donations"
          value={donations.length}
          color="oklch(42% 0.12 195)"
        />
        <StatCard
          icon={DollarSign}
          label="Total Raised"
          value={centsToDollars(totalAmount)}
          color="oklch(50% 0.15 150)"
        />
        <StatCard
          icon={MessageSquare}
          label="Contact Messages"
          value={contacts.length}
          color="oklch(55% 0.14 260)"
        />
        <StatCard
          icon={Target}
          label="Active Campaigns"
          value={campaigns.length}
          color="oklch(60% 0.16 30)"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Donations */}
        <Card className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="font-display font-bold text-base text-[oklch(18%_0.025_60)] flex items-center gap-2">
              <TrendingUp size={16} className="text-[oklch(42%_0.12_195)]" />
              Recent Donations
            </CardTitle>
            <CardDescription className="font-body text-xs">
              Latest 5 donations received
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {recent5Donations.length === 0 ? (
              <div
                data-ocid="overview.donations.empty_state"
                className="text-center py-6 text-[oklch(60%_0.02_60)] text-sm font-body"
              >
                No donations yet.
              </div>
            ) : (
              <div className="space-y-2">
                {recent5Donations.map((d, i) => {
                  const campaign = campaigns.find((c) => c.id === d.campaignId);
                  return (
                    <div
                      key={d.id}
                      data-ocid={`overview.donations.item.${i + 1}`}
                      className="flex items-center justify-between gap-2 py-2 border-b border-[oklch(95%_0.005_80)] last:border-0"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-[oklch(22%_0.025_60)] truncate">
                          {d.donorName}
                        </div>
                        <div className="text-xs text-[oklch(55%_0.02_60)] truncate">
                          {campaign?.name ?? `Campaign #${d.campaignId}`}
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="text-sm font-bold text-[oklch(42%_0.12_195)]">
                          {centsToDollars(d.amount)}
                        </div>
                        <div className="text-xs text-[oklch(60%_0.02_60)]">
                          {formatDate(d.timestamp)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Messages */}
        <Card className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="font-display font-bold text-base text-[oklch(18%_0.025_60)] flex items-center gap-2">
              <Mail size={16} className="text-[oklch(55%_0.14_260)]" />
              Recent Messages
            </CardTitle>
            <CardDescription className="font-body text-xs">
              Latest 5 contact messages
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {recent5Contacts.length === 0 ? (
              <div
                data-ocid="overview.contacts.empty_state"
                className="text-center py-6 text-[oklch(60%_0.02_60)] text-sm font-body"
              >
                No messages yet.
              </div>
            ) : (
              <div className="space-y-2">
                {recent5Contacts.map((c, i) => (
                  <div
                    key={c.id}
                    data-ocid={`overview.contacts.item.${i + 1}`}
                    className="flex items-start justify-between gap-2 py-2 border-b border-[oklch(95%_0.005_80)] last:border-0"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-[oklch(22%_0.025_60)]">
                        {c.name}
                      </div>
                      <div className="text-xs text-[oklch(50%_0.02_60)] line-clamp-2 mt-0.5">
                        {c.message}
                      </div>
                    </div>
                    <div className="text-xs text-[oklch(60%_0.02_60)] whitespace-nowrap flex-shrink-0">
                      {formatDate(c.timestamp)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// ── Donations Tab ───────────────────────────────────────────

function DonationsTab({
  donations,
  campaigns,
  onDonationsChange,
}: {
  donations: LocalDonation[];
  campaigns: LocalCampaign[];
  onDonationsChange: (d: LocalDonation[]) => void;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [form, setForm] = useState({
    donorName: "",
    email: "",
    amount: "",
    campaignId: String(campaigns[0]?.id ?? "1"),
    message: "",
  });

  const handleAdd = () => {
    if (!form.donorName.trim() || !form.email.trim() || !form.amount) {
      toast.error("Please fill in all required fields.");
      return;
    }
    const amountCents = Math.round(Number.parseFloat(form.amount) * 100);
    if (Number.isNaN(amountCents) || amountCents <= 0) {
      toast.error("Please enter a valid amount.");
      return;
    }
    const newDonation: LocalDonation = {
      id: generateId(),
      donorName: form.donorName.trim(),
      email: form.email.trim(),
      amount: amountCents,
      campaignId: Number.parseInt(form.campaignId, 10),
      message: form.message.trim(),
      timestamp: Date.now(),
    };
    const updated = [...donations, newDonation];
    onDonationsChange(updated);
    window.localStorage.setItem(LS_DONATIONS, JSON.stringify(updated));
    setAddOpen(false);
    setForm({
      donorName: "",
      email: "",
      amount: "",
      campaignId: String(campaigns[0]?.id ?? "1"),
      message: "",
    });
    toast.success("Donation added successfully!");
  };

  const handleDelete = (id: string) => {
    const updated = donations.filter((d) => d.id !== id);
    onDonationsChange(updated);
    window.localStorage.setItem(LS_DONATIONS, JSON.stringify(updated));
    setDeleteTarget(null);
    toast.success("Donation deleted.");
  };

  const sorted = [...donations].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="bg-white rounded-2xl border border-[oklch(90%_0.01_80)] shadow-warm overflow-hidden">
      <div className="p-6 border-b border-[oklch(90%_0.01_80)] flex items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            All Donations
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            {donations.length} donation{donations.length !== 1 ? "s" : ""}{" "}
            recorded
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="donations.open_modal_button"
          onClick={() => setAddOpen(true)}
          className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus size={14} />
          Add Donation
        </Button>
      </div>

      {sorted.length === 0 ? (
        <div
          data-ocid="donations.empty_state"
          className="text-center py-16 text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No donations recorded yet.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table data-ocid="donations.table">
            <TableHeader>
              <TableRow className="border-[oklch(90%_0.01_80)] hover:bg-transparent">
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  #
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Donor Name
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Email
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Amount
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Campaign
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Message
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Date
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sorted.map((d, i) => {
                const campaign = campaigns.find((c) => c.id === d.campaignId);
                return (
                  <TableRow
                    key={d.id}
                    data-ocid={`donations.item.${i + 1}`}
                    className="border-[oklch(93%_0.008_80)] hover:bg-[oklch(97%_0.008_80)]"
                  >
                    <TableCell className="text-[oklch(55%_0.02_60)] text-sm">
                      {i + 1}
                    </TableCell>
                    <TableCell className="font-semibold text-[oklch(22%_0.025_60)] text-sm">
                      {d.donorName}
                    </TableCell>
                    <TableCell className="text-[oklch(45%_0.02_60)] text-sm">
                      {d.email}
                    </TableCell>
                    <TableCell>
                      <span className="font-bold text-[oklch(42%_0.12_195)] text-sm">
                        {centsToDollars(d.amount)}
                      </span>
                    </TableCell>
                    <TableCell className="text-[oklch(45%_0.02_60)] text-sm">
                      {campaign?.name ?? `Campaign #${d.campaignId}`}
                    </TableCell>
                    <TableCell className="text-[oklch(50%_0.02_60)] text-sm max-w-[180px]">
                      <div className="truncate">
                        {d.message || (
                          <span className="italic text-[oklch(65%_0.02_60)]">
                            —
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-[oklch(55%_0.02_60)] text-xs whitespace-nowrap">
                      {formatDate(d.timestamp)}
                    </TableCell>
                    <TableCell>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        data-ocid={`donations.delete_button.${i + 1}`}
                        onClick={() => setDeleteTarget(d.id)}
                        className="text-[oklch(55%_0.15_20)] hover:text-[oklch(42%_0.18_20)] hover:bg-[oklch(95%_0.02_20)] h-7 w-7 p-0 rounded-lg"
                      >
                        <Trash2 size={13} />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Add Donation Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent
          className="sm:max-w-md bg-white"
          data-ocid="donations.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Add Donation
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              Manually record a new donation entry.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Donor Name <span className="text-destructive">*</span>
              </Label>
              <Input
                data-ocid="donations.name.input"
                placeholder="Rahul Sharma"
                value={form.donorName}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, donorName: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Email <span className="text-destructive">*</span>
              </Label>
              <Input
                type="email"
                data-ocid="donations.email.input"
                placeholder="donor@example.com"
                value={form.email}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, email: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Amount (USD) <span className="text-destructive">*</span>
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[oklch(45%_0.02_60)] font-semibold text-sm">
                  $
                </span>
                <Input
                  type="number"
                  min="1"
                  step="0.01"
                  data-ocid="donations.amount.input"
                  placeholder="50.00"
                  value={form.amount}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, amount: e.target.value }))
                  }
                  className="pl-7 border-[oklch(88%_0.01_80)]"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Campaign
              </Label>
              <Select
                value={form.campaignId}
                onValueChange={(v) =>
                  setForm((prev) => ({ ...prev, campaignId: v }))
                }
              >
                <SelectTrigger
                  data-ocid="donations.campaign.select"
                  className="border-[oklch(88%_0.01_80)]"
                >
                  <SelectValue placeholder="Select campaign" />
                </SelectTrigger>
                <SelectContent>
                  {campaigns.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Message (Optional)
              </Label>
              <Textarea
                data-ocid="donations.message.textarea"
                placeholder="Donor's message..."
                rows={3}
                value={form.message}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, message: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)] resize-none"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="donations.cancel_button"
              onClick={() => setAddOpen(false)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="donations.submit_button"
              onClick={handleAdd}
              className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white"
            >
              Add Donation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="donations.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Donation
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="donations.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="donations.delete.confirm_button"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Contacts Tab ─────────────────────────────────────────────

function ContactsTab({
  contacts,
  onContactsChange,
}: {
  contacts: LocalContact[];
  onContactsChange: (c: LocalContact[]) => void;
}) {
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const handleDelete = (id: string) => {
    const updated = contacts.filter((c) => c.id !== id);
    onContactsChange(updated);
    window.localStorage.setItem(LS_CONTACTS, JSON.stringify(updated));
    setDeleteTarget(null);
    toast.success("Message deleted.");
  };

  const sorted = [...contacts].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="bg-white rounded-2xl border border-[oklch(90%_0.01_80)] shadow-warm overflow-hidden">
      <div className="p-6 border-b border-[oklch(90%_0.01_80)]">
        <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
          Contact Messages
        </h2>
        <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
          {contacts.length} message{contacts.length !== 1 ? "s" : ""} received
        </p>
      </div>

      {sorted.length === 0 ? (
        <div
          data-ocid="contacts.empty_state"
          className="text-center py-16 text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No contact messages yet.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table data-ocid="contacts.table">
            <TableHeader>
              <TableRow className="border-[oklch(90%_0.01_80)] hover:bg-transparent">
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  #
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Name
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Email
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Message
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Date
                </TableHead>
                <TableHead className="text-[oklch(45%_0.02_60)] font-semibold text-xs">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sorted.map((c, i) => (
                <TableRow
                  key={c.id}
                  data-ocid={`contacts.item.${i + 1}`}
                  className="border-[oklch(93%_0.008_80)] hover:bg-[oklch(97%_0.008_80)]"
                >
                  <TableCell className="text-[oklch(55%_0.02_60)] text-sm">
                    {i + 1}
                  </TableCell>
                  <TableCell className="font-semibold text-[oklch(22%_0.025_60)] text-sm">
                    {c.name}
                  </TableCell>
                  <TableCell className="text-[oklch(45%_0.02_60)] text-sm">
                    {c.email}
                  </TableCell>
                  <TableCell className="text-[oklch(45%_0.02_60)] text-sm max-w-[250px]">
                    <div className="line-clamp-2">{c.message}</div>
                  </TableCell>
                  <TableCell className="text-[oklch(55%_0.02_60)] text-xs whitespace-nowrap">
                    {formatDate(c.timestamp)}
                  </TableCell>
                  <TableCell>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      data-ocid={`contacts.delete_button.${i + 1}`}
                      onClick={() => setDeleteTarget(c.id)}
                      className="text-[oklch(55%_0.15_20)] hover:text-[oklch(42%_0.18_20)] hover:bg-[oklch(95%_0.02_20)] h-7 w-7 p-0 rounded-lg"
                    >
                      <Trash2 size={13} />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="contacts.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Message
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="contacts.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="contacts.delete.confirm_button"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Campaigns Tab ────────────────────────────────────────────

function CampaignsTab({
  campaigns,
  onCampaignsChange,
}: {
  campaigns: LocalCampaign[];
  onCampaignsChange: (c: LocalCampaign[]) => void;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<number | null>(null);
  const [addForm, setAddForm] = useState({
    name: "",
    description: "",
    goalAmount: "",
  });
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    goalAmount: "",
  });

  const startEdit = (c: LocalCampaign) => {
    setEditId(c.id);
    setEditForm({
      name: c.name,
      description: c.description,
      goalAmount: String(c.goalAmount),
    });
  };

  const handleSaveEdit = () => {
    if (!editForm.name.trim()) {
      toast.error("Campaign name is required.");
      return;
    }
    const goal = Number.parseFloat(editForm.goalAmount);
    if (Number.isNaN(goal) || goal <= 0) {
      toast.error("Please enter a valid goal amount.");
      return;
    }
    const updated = campaigns.map((c) =>
      c.id === editId
        ? {
            ...c,
            name: editForm.name.trim(),
            description: editForm.description.trim(),
            goalAmount: goal,
          }
        : c,
    );
    onCampaignsChange(updated);
    window.localStorage.setItem(LS_CAMPAIGNS, JSON.stringify(updated));
    setEditId(null);
    toast.success("Campaign updated!");
  };

  const handleAdd = () => {
    if (!addForm.name.trim()) {
      toast.error("Campaign name is required.");
      return;
    }
    const goal = Number.parseFloat(addForm.goalAmount);
    if (Number.isNaN(goal) || goal <= 0) {
      toast.error("Please enter a valid goal amount.");
      return;
    }
    const maxId = campaigns.reduce((m, c) => Math.max(m, c.id), 0);
    const newCampaign: LocalCampaign = {
      id: maxId + 1,
      name: addForm.name.trim(),
      description: addForm.description.trim(),
      goalAmount: goal,
    };
    const updated = [...campaigns, newCampaign];
    onCampaignsChange(updated);
    window.localStorage.setItem(LS_CAMPAIGNS, JSON.stringify(updated));
    setAddOpen(false);
    setAddForm({ name: "", description: "", goalAmount: "" });
    toast.success("Campaign added!");
  };

  const handleDelete = (id: number) => {
    const updated = campaigns.filter((c) => c.id !== id);
    onCampaignsChange(updated);
    window.localStorage.setItem(LS_CAMPAIGNS, JSON.stringify(updated));
    setDeleteTarget(null);
    toast.success("Campaign deleted.");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            Campaigns
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            Manage your fundraising campaigns
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="campaigns.open_modal_button"
          onClick={() => setAddOpen(true)}
          className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus size={14} />
          New Campaign
        </Button>
      </div>

      {campaigns.length === 0 ? (
        <div
          data-ocid="campaigns.empty_state"
          className="text-center py-16 bg-white rounded-2xl border border-[oklch(90%_0.01_80)] text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No campaigns yet. Add one above.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {campaigns.map((c, i) => (
            <Card
              key={c.id}
              data-ocid={`campaigns.item.${i + 1}`}
              className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl"
            >
              {editId === c.id ? (
                <CardContent className="p-5 space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Name
                    </Label>
                    <Input
                      data-ocid={`campaigns.name.input.${i + 1}`}
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Description
                    </Label>
                    <Textarea
                      data-ocid={`campaigns.description.textarea.${i + 1}`}
                      value={editForm.description}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          description: e.target.value,
                        }))
                      }
                      rows={3}
                      className="border-[oklch(88%_0.01_80)] text-sm resize-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Goal (USD)
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[oklch(45%_0.02_60)] font-semibold text-sm">
                        $
                      </span>
                      <Input
                        type="number"
                        min="1"
                        data-ocid={`campaigns.goal.input.${i + 1}`}
                        value={editForm.goalAmount}
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            goalAmount: e.target.value,
                          }))
                        }
                        className="pl-7 border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      size="sm"
                      data-ocid={`campaigns.save_button.${i + 1}`}
                      onClick={handleSaveEdit}
                      className="flex-1 bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-lg text-xs"
                    >
                      <Save size={12} className="mr-1" />
                      Save
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      data-ocid={`campaigns.cancel_button.${i + 1}`}
                      onClick={() => setEditId(null)}
                      className="border-[oklch(88%_0.01_80)] text-xs"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              ) : (
                <>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="font-display font-bold text-base text-[oklch(18%_0.025_60)] leading-tight">
                        {c.name}
                      </CardTitle>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`campaigns.edit_button.${i + 1}`}
                          onClick={() => startEdit(c)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(45%_0.1_230)] hover:bg-[oklch(94%_0.04_230)]"
                        >
                          <Edit2 size={13} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`campaigns.delete_button.${i + 1}`}
                          onClick={() => setDeleteTarget(c.id)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(55%_0.15_20)] hover:bg-[oklch(95%_0.02_20)]"
                        >
                          <Trash2 size={13} />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-[oklch(50%_0.02_60)] font-body leading-relaxed mb-3">
                      {c.description || (
                        <span className="italic text-[oklch(65%_0.02_60)]">
                          No description
                        </span>
                      )}
                    </p>
                    <div className="flex items-center gap-2 rounded-xl bg-[oklch(97%_0.01_195)] border border-[oklch(88%_0.06_195)] px-3 py-2">
                      <Target
                        size={13}
                        className="text-[oklch(42%_0.12_195)]"
                      />
                      <span className="text-xs font-semibold text-[oklch(35%_0.06_195)]">
                        Goal:
                      </span>
                      <span className="text-sm font-bold text-[oklch(42%_0.12_195)]">
                        ${c.goalAmount.toLocaleString()}
                      </span>
                    </div>
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Add Campaign Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent
          className="sm:max-w-md bg-white"
          data-ocid="campaigns.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              New Campaign
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              Add a new fundraising campaign.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Campaign Name <span className="text-destructive">*</span>
              </Label>
              <Input
                data-ocid="campaigns.add.name.input"
                placeholder="Education Fund 2027"
                value={addForm.name}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, name: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Description
              </Label>
              <Textarea
                data-ocid="campaigns.add.description.textarea"
                placeholder="Describe this campaign..."
                rows={3}
                value={addForm.description}
                onChange={(e) =>
                  setAddForm((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                className="border-[oklch(88%_0.01_80)] resize-none"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Goal Amount (USD) <span className="text-destructive">*</span>
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[oklch(45%_0.02_60)] font-semibold text-sm">
                  $
                </span>
                <Input
                  type="number"
                  min="1"
                  data-ocid="campaigns.add.goal.input"
                  placeholder="10000"
                  value={addForm.goalAmount}
                  onChange={(e) =>
                    setAddForm((prev) => ({
                      ...prev,
                      goalAmount: e.target.value,
                    }))
                  }
                  className="pl-7 border-[oklch(88%_0.01_80)]"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="campaigns.add.cancel_button"
              onClick={() => setAddOpen(false)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="campaigns.add.submit_button"
              onClick={handleAdd}
              className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white"
            >
              Create Campaign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="campaigns.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Campaign
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="campaigns.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="campaigns.delete.confirm_button"
              onClick={() =>
                deleteTarget !== null && handleDelete(deleteTarget)
              }
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Site Content Tab ─────────────────────────────────────────

function SiteContentTab({
  content,
  onContentChange,
}: {
  content: SiteContent;
  onContentChange: (c: SiteContent) => void;
}) {
  const [form, setForm] = useState<SiteContent>(content);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 350));
    onContentChange(form);
    window.localStorage.setItem(LS_SITE_CONTENT, JSON.stringify(form));
    window.dispatchEvent(new Event("cymi_site_content_updated"));
    setSaving(false);
    toast.success("Site content saved successfully!");
  };

  const field = (
    label: string,
    key: keyof SiteContent,
    ocid: string,
    multiline = false,
    placeholder = "",
  ) => (
    <div className="space-y-1.5" key={key}>
      <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
        {label}
      </Label>
      {multiline ? (
        <Textarea
          data-ocid={ocid}
          value={form[key]}
          placeholder={placeholder}
          rows={3}
          onChange={(e) =>
            setForm((prev) => ({ ...prev, [key]: e.target.value }))
          }
          className="border-[oklch(88%_0.01_80)] resize-none font-body text-sm"
        />
      ) : (
        <Input
          data-ocid={ocid}
          value={form[key]}
          placeholder={placeholder}
          onChange={(e) =>
            setForm((prev) => ({ ...prev, [key]: e.target.value }))
          }
          className="border-[oklch(88%_0.01_80)] text-sm"
        />
      )}
    </div>
  );

  return (
    <div className="bg-white rounded-2xl border border-[oklch(90%_0.01_80)] shadow-warm overflow-hidden">
      <div className="p-6 border-b border-[oklch(90%_0.01_80)] flex items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            Site Content
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            Edit all text content displayed on your website.
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="site_content.save_button"
          onClick={handleSave}
          disabled={saving}
          className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl flex items-center gap-1.5"
        >
          {saving ? (
            <Loader2 size={14} className="animate-spin" />
          ) : (
            <Save size={14} />
          )}
          {saving ? "Saving..." : "Save Changes"}
        </Button>
      </div>
      <div className="p-6 space-y-8">
        {/* Hero Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[oklch(93%_0.008_80)]">
            <Globe size={14} className="text-[oklch(42%_0.12_195)]" />
            <h3 className="text-sm font-bold text-[oklch(30%_0.025_60)] uppercase tracking-wide">
              Hero Section
            </h3>
          </div>
          {field(
            "Hero Headline",
            "heroHeadline",
            "site_content.hero_headline.input",
            false,
            "Every Child Deserves a Future",
          )}
          {field(
            "Hero Tagline",
            "heroTagline",
            "site_content.hero_tagline.textarea",
            true,
            "Your main hero tagline...",
          )}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {field(
              "Trust Indicator 1",
              "heroTrust1",
              "site_content.hero_trust1.input",
              false,
              "150+ Children in Our Care",
            )}
            {field(
              "Trust Indicator 2",
              "heroTrust2",
              "site_content.hero_trust2.input",
              false,
              "10 Years of Service",
            )}
            {field(
              "Trust Indicator 3",
              "heroTrust3",
              "site_content.hero_trust3.input",
              false,
              "500+ Donors Worldwide",
            )}
          </div>
        </div>

        {/* About Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[oklch(93%_0.008_80)]">
            <BookOpen size={14} className="text-[oklch(50%_0.15_150)]" />
            <h3 className="text-sm font-bold text-[oklch(30%_0.025_60)] uppercase tracking-wide">
              About Us
            </h3>
          </div>
          {field(
            "Mission Subheading",
            "aboutSubheading",
            "site_content.about_subheading.input",
            false,
            "Transforming Lives, One Child at a Time",
          )}
          {field(
            "About Bio (Highlighted Quote)",
            "aboutBio",
            "site_content.about_bio.textarea",
            true,
            "Your organization's highlighted bio...",
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {field(
              "Founded Year",
              "aboutFoundedYear",
              "site_content.about_founded.input",
              false,
              "2015",
            )}
            {field(
              "Location",
              "aboutLocation",
              "site_content.about_location.input",
              false,
              "Karnataka, India",
            )}
          </div>
          {field(
            "Story Paragraph 1",
            "aboutStory1",
            "site_content.about_story1.textarea",
            true,
            "First paragraph of your story...",
          )}
          {field(
            "Story Paragraph 2",
            "aboutStory2",
            "site_content.about_story2.textarea",
            true,
            "Second paragraph of your story...",
          )}
        </div>

        {/* Impact Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[oklch(93%_0.008_80)]">
            <TrendingUp size={14} className="text-[oklch(60%_0.16_30)]" />
            <h3 className="text-sm font-bold text-[oklch(30%_0.025_60)] uppercase tracking-wide">
              Impact Section
            </h3>
          </div>
          {field(
            "Impact Quote",
            "impactQuote",
            "site_content.impact_quote.textarea",
            true,
            '"We have seen children grow from hopelessness to becoming leaders."',
          )}
          {field(
            "Quote Author",
            "impactQuoteAuthor",
            "site_content.impact_quote_author.input",
            false,
            "— Director, CYMI Children Home",
          )}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {field(
              "Children Count",
              "childrenCount",
              "site_content.children_count.input",
              false,
              "150+",
            )}
            {field(
              "Years of Service",
              "yearsOfService",
              "site_content.years_service.input",
              false,
              "10",
            )}
            {field(
              "Donors Count",
              "donorsCount",
              "site_content.donors_count.input",
              false,
              "500+",
            )}
            {field(
              "Graduation Rate",
              "graduationRate",
              "site_content.graduation_rate.input",
              false,
              "95%",
            )}
          </div>
        </div>

        {/* Contact */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[oklch(93%_0.008_80)]">
            <Users size={14} className="text-[oklch(55%_0.14_260)]" />
            <h3 className="text-sm font-bold text-[oklch(30%_0.025_60)] uppercase tracking-wide">
              Contact Information
            </h3>
          </div>
          {field(
            "Contact Email",
            "contactEmail",
            "site_content.contact_email.input",
            false,
            "info@cymi.org",
          )}
          {field(
            "Contact Phone",
            "contactPhone",
            "site_content.contact_phone.input",
            false,
            "+1 000 000 0000",
          )}
          {field(
            "Contact Address",
            "contactAddress",
            "site_content.contact_address.textarea",
            true,
            "123 Main Street...",
          )}
        </div>

        {/* Footer */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[oklch(93%_0.008_80)]">
            <Heart size={14} className="text-[oklch(55%_0.22_20)]" />
            <h3 className="text-sm font-bold text-[oklch(30%_0.025_60)] uppercase tracking-wide">
              Footer
            </h3>
          </div>
          {field(
            "Footer Tagline",
            "footerTagline",
            "site_content.footer_tagline.textarea",
            true,
            "Transforming Lives, One Child at a Time...",
          )}
          {field(
            "NGO / Registration Note",
            "footerNgoNote",
            "site_content.footer_ngo_note.input",
            false,
            "Registered Non-Governmental Organisation",
          )}
        </div>

        {/* Mobile Save */}
        <div className="pt-2 flex justify-end">
          <Button
            type="button"
            data-ocid="site_content.bottom.save_button"
            onClick={handleSave}
            disabled={saving}
            className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl px-6"
          >
            {saving ? (
              <Loader2 size={14} className="mr-2 animate-spin" />
            ) : (
              <Save size={14} className="mr-2" />
            )}
            {saving ? "Saving..." : "Save All Changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Testimonials Tab ─────────────────────────────────────────

const STAR_OPTIONS = [1, 2, 3, 4, 5];

function TestimonialsTab({
  testimonials,
  onTestimonialsChange,
}: {
  testimonials: LocalTestimonial[];
  onTestimonialsChange: (t: LocalTestimonial[]) => void;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [addForm, setAddForm] = useState({
    name: "",
    role: "",
    quote: "",
    avatarInitials: "",
    rating: "5",
  });
  const [editForm, setEditForm] = useState({
    name: "",
    role: "",
    quote: "",
    avatarInitials: "",
    rating: "5",
  });

  const startEdit = (t: LocalTestimonial) => {
    setEditId(t.id);
    setEditForm({
      name: t.name,
      role: t.role,
      quote: t.quote,
      avatarInitials: t.avatarInitials,
      rating: String(t.rating),
    });
  };

  const handleSaveEdit = () => {
    if (!editForm.name.trim() || !editForm.quote.trim()) {
      toast.error("Name and quote are required.");
      return;
    }
    const updated = testimonials.map((t) =>
      t.id === editId
        ? {
            ...t,
            name: editForm.name.trim(),
            role: editForm.role.trim(),
            quote: editForm.quote.trim(),
            avatarInitials:
              editForm.avatarInitials.trim().slice(0, 3).toUpperCase() ||
              editForm.name.slice(0, 2).toUpperCase(),
            rating: Number.parseInt(editForm.rating, 10),
          }
        : t,
    );
    onTestimonialsChange(updated);
    window.localStorage.setItem(LS_TESTIMONIALS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_testimonials_updated"));
    setEditId(null);
    toast.success("Testimonial updated!");
  };

  const handleAdd = () => {
    if (!addForm.name.trim() || !addForm.quote.trim()) {
      toast.error("Name and quote are required.");
      return;
    }
    const newTestimonial: LocalTestimonial = {
      id: generateId(),
      name: addForm.name.trim(),
      role: addForm.role.trim(),
      quote: addForm.quote.trim(),
      avatarInitials:
        addForm.avatarInitials.trim().slice(0, 3).toUpperCase() ||
        addForm.name.slice(0, 2).toUpperCase(),
      rating: Number.parseInt(addForm.rating, 10),
    };
    const updated = [...testimonials, newTestimonial];
    onTestimonialsChange(updated);
    window.localStorage.setItem(LS_TESTIMONIALS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_testimonials_updated"));
    setAddOpen(false);
    setAddForm({
      name: "",
      role: "",
      quote: "",
      avatarInitials: "",
      rating: "5",
    });
    toast.success("Testimonial added!");
  };

  const handleDelete = (id: string) => {
    const updated = testimonials.filter((t) => t.id !== id);
    onTestimonialsChange(updated);
    window.localStorage.setItem(LS_TESTIMONIALS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_testimonials_updated"));
    setDeleteTarget(null);
    toast.success("Testimonial deleted.");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            Testimonials
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            Manage donor and supporter testimonials
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="testimonials.open_modal_button"
          onClick={() => setAddOpen(true)}
          className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus size={14} />
          Add Testimonial
        </Button>
      </div>

      {testimonials.length === 0 ? (
        <div
          data-ocid="testimonials.empty_state"
          className="text-center py-16 bg-white rounded-2xl border border-[oklch(90%_0.01_80)] text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No testimonials yet. Add one above.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <Card
              key={t.id}
              data-ocid={`testimonials.item.${i + 1}`}
              className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl"
            >
              {editId === t.id ? (
                <CardContent className="p-5 space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      data-ocid={`testimonials.name.input.${i + 1}`}
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Role / Location
                    </Label>
                    <Input
                      data-ocid={`testimonials.role.input.${i + 1}`}
                      value={editForm.role}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          role: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Quote <span className="text-destructive">*</span>
                    </Label>
                    <Textarea
                      data-ocid={`testimonials.quote.textarea.${i + 1}`}
                      value={editForm.quote}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          quote: e.target.value,
                        }))
                      }
                      rows={3}
                      className="border-[oklch(88%_0.01_80)] text-sm resize-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Initials
                      </Label>
                      <Input
                        data-ocid={`testimonials.initials.input.${i + 1}`}
                        value={editForm.avatarInitials}
                        maxLength={3}
                        placeholder="SM"
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            avatarInitials: e.target.value,
                          }))
                        }
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Rating
                      </Label>
                      <Select
                        value={editForm.rating}
                        onValueChange={(v) =>
                          setEditForm((prev) => ({ ...prev, rating: v }))
                        }
                      >
                        <SelectTrigger
                          data-ocid={`testimonials.rating.select.${i + 1}`}
                          className="border-[oklch(88%_0.01_80)] text-sm"
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STAR_OPTIONS.map((n) => (
                            <SelectItem key={n} value={String(n)}>
                              {"★".repeat(n)} ({n})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      size="sm"
                      data-ocid={`testimonials.save_button.${i + 1}`}
                      onClick={handleSaveEdit}
                      className="flex-1 bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-lg text-xs"
                    >
                      <Save size={12} className="mr-1" />
                      Save
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      data-ocid={`testimonials.cancel_button.${i + 1}`}
                      onClick={() => setEditId(null)}
                      className="border-[oklch(88%_0.01_80)] text-xs"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              ) : (
                <>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-[oklch(42%_0.12_195_/_0.12)] flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-[oklch(42%_0.12_195)]">
                            {t.avatarInitials}
                          </span>
                        </div>
                        <div>
                          <CardTitle className="font-display font-bold text-sm text-[oklch(18%_0.025_60)] leading-tight">
                            {t.name}
                          </CardTitle>
                          <p className="text-xs text-[oklch(55%_0.02_60)] font-body">
                            {t.role}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`testimonials.edit_button.${i + 1}`}
                          onClick={() => startEdit(t)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(45%_0.1_230)] hover:bg-[oklch(94%_0.04_230)]"
                        >
                          <Edit2 size={13} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`testimonials.delete_button.${i + 1}`}
                          onClick={() => setDeleteTarget(t.id)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(55%_0.15_20)] hover:bg-[oklch(95%_0.02_20)]"
                        >
                          <Trash2 size={13} />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-xs text-[oklch(45%_0.02_60)] font-body line-clamp-3 mb-3 italic">
                      "{t.quote}"
                    </p>
                    <div className="flex gap-0.5">
                      {Array.from({ length: t.rating }, (_, idx) => (
                        <Star
                          key={`star-${t.id}-${idx}`}
                          size={11}
                          className="fill-[oklch(75%_0.16_75)] text-[oklch(75%_0.16_75)]"
                        />
                      ))}
                    </div>
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Add Testimonial Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent
          className="sm:max-w-md bg-white"
          data-ocid="testimonials.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Add Testimonial
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              Add a new donor or supporter testimonial.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Name <span className="text-destructive">*</span>
              </Label>
              <Input
                data-ocid="testimonials.add.name.input"
                placeholder="Sarah M."
                value={addForm.name}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, name: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Role / Location
              </Label>
              <Input
                data-ocid="testimonials.add.role.input"
                placeholder="Monthly Donor, United Kingdom"
                value={addForm.role}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, role: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Quote <span className="text-destructive">*</span>
              </Label>
              <Textarea
                data-ocid="testimonials.add.quote.textarea"
                placeholder="Their experience with CYMI..."
                rows={4}
                value={addForm.quote}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, quote: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)] resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Avatar Initials
                </Label>
                <Input
                  data-ocid="testimonials.add.initials.input"
                  placeholder="SM"
                  maxLength={3}
                  value={addForm.avatarInitials}
                  onChange={(e) =>
                    setAddForm((prev) => ({
                      ...prev,
                      avatarInitials: e.target.value,
                    }))
                  }
                  className="border-[oklch(88%_0.01_80)]"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Star Rating
                </Label>
                <Select
                  value={addForm.rating}
                  onValueChange={(v) =>
                    setAddForm((prev) => ({ ...prev, rating: v }))
                  }
                >
                  <SelectTrigger
                    data-ocid="testimonials.add.rating.select"
                    className="border-[oklch(88%_0.01_80)]"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STAR_OPTIONS.map((n) => (
                      <SelectItem key={n} value={String(n)}>
                        {"★".repeat(n)} ({n})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="testimonials.add.cancel_button"
              onClick={() => setAddOpen(false)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="testimonials.add.submit_button"
              onClick={handleAdd}
              className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white"
            >
              Add Testimonial
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="testimonials.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Testimonial
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="testimonials.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="testimonials.delete.confirm_button"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Partners Tab ─────────────────────────────────────────────

function PartnersTab({
  partners,
  onPartnersChange,
}: {
  partners: LocalPartner[];
  onPartnersChange: (p: LocalPartner[]) => void;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [addForm, setAddForm] = useState({
    name: "",
    description: "",
    logoInitials: "",
    logoUrl: "",
    website: "",
  });
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    logoInitials: "",
    logoUrl: "",
    website: "",
  });

  const startEdit = (p: LocalPartner) => {
    setEditId(p.id);
    setEditForm({
      name: p.name,
      description: p.description,
      logoInitials: p.logoInitials,
      logoUrl: p.logoUrl,
      website: p.website,
    });
  };

  const handleSaveEdit = () => {
    if (!editForm.name.trim()) {
      toast.error("Partner name is required.");
      return;
    }
    const updated = partners.map((p) =>
      p.id === editId
        ? {
            ...p,
            name: editForm.name.trim(),
            description: editForm.description.trim(),
            logoInitials:
              editForm.logoInitials.trim().slice(0, 3).toUpperCase() ||
              editForm.name.slice(0, 2).toUpperCase(),
            logoUrl: editForm.logoUrl.trim(),
            website: editForm.website.trim(),
          }
        : p,
    );
    onPartnersChange(updated);
    window.localStorage.setItem(LS_PARTNERS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_partners_updated"));
    setEditId(null);
    toast.success("Partner updated!");
  };

  const handleAdd = () => {
    if (!addForm.name.trim()) {
      toast.error("Partner name is required.");
      return;
    }
    const newPartner: LocalPartner = {
      id: generateId(),
      name: addForm.name.trim(),
      description: addForm.description.trim(),
      logoInitials:
        addForm.logoInitials.trim().slice(0, 3).toUpperCase() ||
        addForm.name.slice(0, 2).toUpperCase(),
      logoUrl: addForm.logoUrl.trim(),
      website: addForm.website.trim(),
    };
    const updated = [...partners, newPartner];
    onPartnersChange(updated);
    window.localStorage.setItem(LS_PARTNERS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_partners_updated"));
    setAddOpen(false);
    setAddForm({
      name: "",
      description: "",
      logoInitials: "",
      logoUrl: "",
      website: "",
    });
    toast.success("Partner added!");
  };

  const handleDelete = (id: string) => {
    const updated = partners.filter((p) => p.id !== id);
    onPartnersChange(updated);
    window.localStorage.setItem(LS_PARTNERS, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_partners_updated"));
    setDeleteTarget(null);
    toast.success("Partner deleted.");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            Partners
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            Manage your organisation's partners and collaborators
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="partners.open_modal_button"
          onClick={() => setAddOpen(true)}
          className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus size={14} />
          Add Partner
        </Button>
      </div>

      {partners.length === 0 ? (
        <div
          data-ocid="partners.empty_state"
          className="text-center py-16 bg-white rounded-2xl border border-[oklch(90%_0.01_80)] text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No partners yet. Add one above.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {partners.map((p, i) => (
            <Card
              key={p.id}
              data-ocid={`partners.item.${i + 1}`}
              className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl"
            >
              {editId === p.id ? (
                <CardContent className="p-5 space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Partner Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      data-ocid={`partners.name.input.${i + 1}`}
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Description
                    </Label>
                    <Textarea
                      data-ocid={`partners.description.textarea.${i + 1}`}
                      value={editForm.description}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          description: e.target.value,
                        }))
                      }
                      rows={2}
                      className="border-[oklch(88%_0.01_80)] text-sm resize-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Logo Initials
                      </Label>
                      <Input
                        data-ocid={`partners.initials.input.${i + 1}`}
                        value={editForm.logoInitials}
                        maxLength={3}
                        placeholder="WV"
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            logoInitials: e.target.value,
                          }))
                        }
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Logo URL (optional)
                      </Label>
                      <Input
                        data-ocid={`partners.logo_url.input.${i + 1}`}
                        value={editForm.logoUrl}
                        placeholder="https://..."
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            logoUrl: e.target.value,
                          }))
                        }
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Website URL (optional)
                    </Label>
                    <Input
                      data-ocid={`partners.website.input.${i + 1}`}
                      value={editForm.website}
                      placeholder="https://www.example.org"
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          website: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      size="sm"
                      data-ocid={`partners.save_button.${i + 1}`}
                      onClick={handleSaveEdit}
                      className="flex-1 bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-lg text-xs"
                    >
                      <Save size={12} className="mr-1" />
                      Save
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      data-ocid={`partners.cancel_button.${i + 1}`}
                      onClick={() => setEditId(null)}
                      className="border-[oklch(88%_0.01_80)] text-xs"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              ) : (
                <>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[oklch(42%_0.12_195_/_0.1)] flex items-center justify-center flex-shrink-0">
                          {p.logoUrl ? (
                            <img
                              src={p.logoUrl}
                              alt={p.name}
                              className="w-6 h-6 object-contain"
                            />
                          ) : (
                            <span className="text-xs font-bold text-[oklch(42%_0.12_195)]">
                              {p.logoInitials}
                            </span>
                          )}
                        </div>
                        <CardTitle className="font-display font-bold text-sm text-[oklch(18%_0.025_60)] leading-tight">
                          {p.name}
                        </CardTitle>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`partners.edit_button.${i + 1}`}
                          onClick={() => startEdit(p)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(45%_0.1_230)] hover:bg-[oklch(94%_0.04_230)]"
                        >
                          <Edit2 size={13} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`partners.delete_button.${i + 1}`}
                          onClick={() => setDeleteTarget(p.id)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(55%_0.15_20)] hover:bg-[oklch(95%_0.02_20)]"
                        >
                          <Trash2 size={13} />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-xs text-[oklch(50%_0.02_60)] font-body line-clamp-2 mb-3">
                      {p.description || (
                        <span className="italic text-[oklch(65%_0.02_60)]">
                          No description
                        </span>
                      )}
                    </p>
                    {p.website && (
                      <a
                        href={p.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-[oklch(42%_0.12_195)] hover:underline font-semibold"
                      >
                        {p.website.replace(/^https?:\/\/(www\.)?/, "")}
                      </a>
                    )}
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Add Partner Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent
          className="sm:max-w-md bg-white"
          data-ocid="partners.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Add Partner
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              Add a new partner organisation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Partner Name <span className="text-destructive">*</span>
              </Label>
              <Input
                data-ocid="partners.add.name.input"
                placeholder="World Vision"
                value={addForm.name}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, name: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Description
              </Label>
              <Textarea
                data-ocid="partners.add.description.textarea"
                placeholder="Brief description of the partnership..."
                rows={3}
                value={addForm.description}
                onChange={(e) =>
                  setAddForm((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                className="border-[oklch(88%_0.01_80)] resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Logo Initials
                </Label>
                <Input
                  data-ocid="partners.add.initials.input"
                  placeholder="WV"
                  maxLength={3}
                  value={addForm.logoInitials}
                  onChange={(e) =>
                    setAddForm((prev) => ({
                      ...prev,
                      logoInitials: e.target.value,
                    }))
                  }
                  className="border-[oklch(88%_0.01_80)]"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Logo URL (optional)
                </Label>
                <Input
                  data-ocid="partners.add.logo_url.input"
                  placeholder="https://..."
                  value={addForm.logoUrl}
                  onChange={(e) =>
                    setAddForm((prev) => ({ ...prev, logoUrl: e.target.value }))
                  }
                  className="border-[oklch(88%_0.01_80)]"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Website URL (optional)
              </Label>
              <Input
                data-ocid="partners.add.website.input"
                placeholder="https://www.example.org"
                value={addForm.website}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, website: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="partners.add.cancel_button"
              onClick={() => setAddOpen(false)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="partners.add.submit_button"
              onClick={handleAdd}
              className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white"
            >
              Add Partner
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="partners.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Partner
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="partners.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="partners.delete.confirm_button"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Children Tab ─────────────────────────────────────────────

const PROGRAM_OPTIONS = [
  "Education Fund 2026",
  "Medical Care & Nutrition",
  "New Dormitory Building",
];

function ChildrenTab({
  childProfiles,
  onChildrenChange,
}: {
  childProfiles: LocalChild[];
  onChildrenChange: (c: LocalChild[]) => void;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [addForm, setAddForm] = useState({
    name: "",
    age: "",
    story: "",
    photoUrl: "",
    photoInitials: "",
    program: PROGRAM_OPTIONS[0],
  });
  const [editForm, setEditForm] = useState({
    name: "",
    age: "",
    story: "",
    photoUrl: "",
    photoInitials: "",
    program: PROGRAM_OPTIONS[0],
  });

  const startEdit = (c: LocalChild) => {
    setEditId(c.id);
    setEditForm({
      name: c.name,
      age: c.age,
      story: c.story,
      photoUrl: c.photoUrl,
      photoInitials: c.photoInitials,
      program: c.program,
    });
  };

  const persistChildren = (updated: LocalChild[]) => {
    onChildrenChange(updated);
    window.localStorage.setItem(LS_CHILDREN, JSON.stringify(updated));
    window.dispatchEvent(new Event("cymi_children_updated"));
  };

  const handleSaveEdit = () => {
    if (!editForm.name.trim() || !editForm.story.trim()) {
      toast.error("Name and story are required.");
      return;
    }
    const updated = childProfiles.map((c) =>
      c.id === editId
        ? {
            ...c,
            name: editForm.name.trim(),
            age: editForm.age.trim(),
            story: editForm.story.trim(),
            photoUrl: editForm.photoUrl.trim(),
            photoInitials:
              editForm.photoInitials.trim().slice(0, 2).toUpperCase() ||
              editForm.name.slice(0, 2).toUpperCase(),
            program: editForm.program,
          }
        : c,
    );
    persistChildren(updated);
    setEditId(null);
    toast.success("Child profile updated!");
  };

  const handleAdd = () => {
    if (!addForm.name.trim() || !addForm.story.trim()) {
      toast.error("Name and story are required.");
      return;
    }
    const newChild: LocalChild = {
      id: generateId(),
      name: addForm.name.trim(),
      age: addForm.age.trim(),
      story: addForm.story.trim(),
      photoUrl: addForm.photoUrl.trim(),
      photoInitials:
        addForm.photoInitials.trim().slice(0, 2).toUpperCase() ||
        addForm.name.slice(0, 2).toUpperCase(),
      program: addForm.program,
    };
    persistChildren([...childProfiles, newChild]);
    setAddOpen(false);
    setAddForm({
      name: "",
      age: "",
      story: "",
      photoUrl: "",
      photoInitials: "",
      program: PROGRAM_OPTIONS[0],
    });
    toast.success("Child profile added!");
  };

  const handleDelete = (id: string) => {
    persistChildren(childProfiles.filter((c) => c.id !== id));
    setDeleteTarget(null);
    toast.success("Child profile deleted.");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-lg text-[oklch(18%_0.025_60)]">
            Children Profiles
          </h2>
          <p className="text-sm text-[oklch(50%_0.02_60)] font-body">
            Manage children's profiles shown in the Fundraising Stories carousel
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          data-ocid="children.open_modal_button"
          onClick={() => setAddOpen(true)}
          className="bg-[oklch(55%_0.14_28)] hover:bg-[oklch(48%_0.14_28)] text-white rounded-xl flex items-center gap-1.5"
        >
          <Plus size={14} />
          Add Child Profile
        </Button>
      </div>

      {childProfiles.length === 0 ? (
        <div
          data-ocid="children.empty_state"
          className="text-center py-16 bg-white rounded-2xl border border-[oklch(90%_0.01_80)] text-[oklch(55%_0.02_60)] font-body text-sm"
        >
          No child profiles yet. Add one above.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {childProfiles.map((c, i) => (
            <Card
              key={c.id}
              data-ocid={`children.item.${i + 1}`}
              className="bg-white border-[oklch(90%_0.01_80)] shadow-warm rounded-2xl"
            >
              {editId === c.id ? (
                <CardContent className="p-5 space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      data-ocid={`children.name.input.${i + 1}`}
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Age
                      </Label>
                      <Input
                        data-ocid={`children.age.input.${i + 1}`}
                        value={editForm.age}
                        placeholder="9 years"
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            age: e.target.value,
                          }))
                        }
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                        Initials
                      </Label>
                      <Input
                        data-ocid={`children.initials.input.${i + 1}`}
                        value={editForm.photoInitials}
                        maxLength={2}
                        placeholder="AR"
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            photoInitials: e.target.value,
                          }))
                        }
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Story / Testimonial{" "}
                      <span className="text-destructive">*</span>
                    </Label>
                    <Textarea
                      data-ocid={`children.story.textarea.${i + 1}`}
                      value={editForm.story}
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          story: e.target.value,
                        }))
                      }
                      rows={3}
                      className="border-[oklch(88%_0.01_80)] text-sm resize-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Photo URL (optional)
                    </Label>
                    <Input
                      data-ocid={`children.photo_url.input.${i + 1}`}
                      value={editForm.photoUrl}
                      placeholder="https://..."
                      onChange={(e) =>
                        setEditForm((prev) => ({
                          ...prev,
                          photoUrl: e.target.value,
                        }))
                      }
                      className="border-[oklch(88%_0.01_80)] text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-[oklch(40%_0.025_60)]">
                      Program
                    </Label>
                    <Select
                      value={editForm.program}
                      onValueChange={(v) =>
                        setEditForm((prev) => ({ ...prev, program: v }))
                      }
                    >
                      <SelectTrigger
                        data-ocid={`children.program.select.${i + 1}`}
                        className="border-[oklch(88%_0.01_80)] text-sm"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PROGRAM_OPTIONS.map((prog) => (
                          <SelectItem key={prog} value={prog}>
                            {prog}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      size="sm"
                      data-ocid={`children.save_button.${i + 1}`}
                      onClick={handleSaveEdit}
                      className="flex-1 bg-[oklch(55%_0.14_28)] hover:bg-[oklch(48%_0.14_28)] text-white rounded-lg text-xs"
                    >
                      <Save size={12} className="mr-1" />
                      Save
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      data-ocid={`children.cancel_button.${i + 1}`}
                      onClick={() => setEditId(null)}
                      className="border-[oklch(88%_0.01_80)] text-xs"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              ) : (
                <>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-[oklch(88%_0.08_28)] flex items-center justify-center overflow-hidden flex-shrink-0">
                          {c.photoUrl ? (
                            <img
                              src={c.photoUrl}
                              alt={c.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="text-sm font-black text-[oklch(40%_0.16_28)]">
                              {c.photoInitials ||
                                c.name.slice(0, 2).toUpperCase()}
                            </span>
                          )}
                        </div>
                        <div>
                          <CardTitle className="font-display font-bold text-sm text-[oklch(18%_0.025_60)] leading-tight">
                            {c.name}
                          </CardTitle>
                          {c.age && (
                            <p className="text-xs text-[oklch(55%_0.02_60)] font-body">
                              {c.age}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`children.edit_button.${i + 1}`}
                          onClick={() => startEdit(c)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(45%_0.1_230)] hover:bg-[oklch(94%_0.04_230)]"
                        >
                          <Edit2 size={13} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          data-ocid={`children.delete_button.${i + 1}`}
                          onClick={() => setDeleteTarget(c.id)}
                          className="h-7 w-7 p-0 rounded-lg text-[oklch(55%_0.15_20)] hover:bg-[oklch(95%_0.02_20)]"
                        >
                          <Trash2 size={13} />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-xs text-[oklch(45%_0.02_60)] font-body line-clamp-3 mb-3 italic">
                      "{c.story}"
                    </p>
                    {c.program && (
                      <span className="inline-block text-[10px] font-bold rounded-full px-2.5 py-0.5 bg-[oklch(42%_0.12_195_/_0.1)] text-[oklch(38%_0.12_195)] border border-[oklch(42%_0.12_195_/_0.2)]">
                        {c.program}
                      </span>
                    )}
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Add Child Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent
          className="sm:max-w-md bg-white"
          data-ocid="children.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Add Child Profile
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              Add a child's story to the Fundraising Stories carousel.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Child's Name <span className="text-destructive">*</span>
              </Label>
              <Input
                data-ocid="children.add.name.input"
                placeholder="Arjun"
                value={addForm.name}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, name: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Age
                </Label>
                <Input
                  data-ocid="children.add.age.input"
                  placeholder="9 years"
                  value={addForm.age}
                  onChange={(e) =>
                    setAddForm((prev) => ({ ...prev, age: e.target.value }))
                  }
                  className="border-[oklch(88%_0.01_80)]"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                  Photo Initials
                </Label>
                <Input
                  data-ocid="children.add.initials.input"
                  placeholder="AR"
                  maxLength={2}
                  value={addForm.photoInitials}
                  onChange={(e) =>
                    setAddForm((prev) => ({
                      ...prev,
                      photoInitials: e.target.value,
                    }))
                  }
                  className="border-[oklch(88%_0.01_80)]"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Story / Testimonial <span className="text-destructive">*</span>
              </Label>
              <Textarea
                data-ocid="children.add.story.textarea"
                placeholder="I love going to school and learning..."
                rows={4}
                value={addForm.story}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, story: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)] resize-none"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Photo URL (optional)
              </Label>
              <Input
                data-ocid="children.add.photo_url.input"
                placeholder="https://..."
                value={addForm.photoUrl}
                onChange={(e) =>
                  setAddForm((prev) => ({ ...prev, photoUrl: e.target.value }))
                }
                className="border-[oklch(88%_0.01_80)]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-[oklch(35%_0.025_60)]">
                Program
              </Label>
              <Select
                value={addForm.program}
                onValueChange={(v) =>
                  setAddForm((prev) => ({ ...prev, program: v }))
                }
              >
                <SelectTrigger
                  data-ocid="children.add.program.select"
                  className="border-[oklch(88%_0.01_80)]"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROGRAM_OPTIONS.map((prog) => (
                    <SelectItem key={prog} value={prog}>
                      {prog}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="children.add.cancel_button"
              onClick={() => setAddOpen(false)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="children.add.submit_button"
              onClick={handleAdd}
              className="bg-[oklch(55%_0.14_28)] hover:bg-[oklch(48%_0.14_28)] text-white"
            >
              Add Child Profile
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <DialogContent
          className="sm:max-w-sm bg-white"
          data-ocid="children.delete.dialog"
        >
          <DialogHeader>
            <DialogTitle className="font-display font-bold text-[oklch(18%_0.025_60)]">
              Delete Child Profile
            </DialogTitle>
            <DialogDescription className="font-body text-sm">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              data-ocid="children.delete.cancel_button"
              onClick={() => setDeleteTarget(null)}
              className="border-[oklch(88%_0.01_80)]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              data-ocid="children.delete.confirm_button"
              onClick={() => deleteTarget && handleDelete(deleteTarget)}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Main Dashboard ───────────────────────────────────────────

export function AdminDashboard({ onBack }: AdminDashboardProps) {
  const { isAdmin, logout } = useAdminAuth();
  const [activeTab, setActiveTab] = useState("overview");

  // localStorage-backed state
  const [donations, setDonations] =
    useState<LocalDonation[]>(getInitialDonations);
  const [contacts, setContacts] = useState<LocalContact[]>(getInitialContacts);
  const [campaigns, setCampaigns] =
    useState<LocalCampaign[]>(getInitialCampaigns);
  const [siteContent, setSiteContent] = useState<SiteContent>(
    getInitialSiteContent,
  );
  const [testimonials, setTestimonials] = useState<LocalTestimonial[]>(
    getInitialTestimonials,
  );
  const [partners, setPartners] = useState<LocalPartner[]>(getInitialPartners);
  const [children, setChildren] = useState<LocalChild[]>(getInitialChildren);

  if (!isAdmin) {
    onBack();
    return null;
  }

  const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);

  const TAB_ICONS: Record<string, React.ElementType> = {
    overview: LayoutDashboard,
    donations: Heart,
    contacts: MessageSquare,
    campaigns: Target,
    "site-content": Globe,
    testimonials: Star,
    partners: Handshake,
    children: Baby,
  };

  return (
    <div className="min-h-screen bg-[oklch(97%_0.008_80)]">
      {/* Header */}
      <div className="bg-white border-b border-[oklch(90%_0.01_80)] shadow-warm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={onBack}
              data-ocid="admin.back.button"
              className="flex items-center gap-1.5 text-sm text-[oklch(45%_0.02_60)] hover:text-[oklch(18%_0.025_60)] transition-colors"
            >
              <ArrowLeft size={15} />
              <span className="hidden sm:inline">Back to Site</span>
            </button>
            <div className="h-5 w-px bg-[oklch(88%_0.01_80)]" />
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[oklch(42%_0.12_195_/_0.12)] flex items-center justify-center">
                <Shield size={14} className="text-[oklch(42%_0.12_195)]" />
              </div>
              <h1 className="font-display font-bold text-base text-[oklch(18%_0.025_60)]">
                Admin Dashboard
              </h1>
            </div>
          </div>

          {/* Quick stats */}
          <div className="hidden md:flex items-center gap-4 text-xs text-[oklch(55%_0.02_60)]">
            <span>
              <span className="font-bold text-[oklch(42%_0.12_195)]">
                {donations.length}
              </span>{" "}
              donations
            </span>
            <span>
              <span className="font-bold text-[oklch(50%_0.15_150)]">
                {centsToDollars(totalAmount)}
              </span>{" "}
              raised
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-[oklch(55%_0.02_60)] hidden sm:block">
              Admin: CYMI
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={logout}
              data-ocid="admin.signout.button"
              className="border-[oklch(88%_0.01_80)] text-[oklch(45%_0.02_60)] hover:text-destructive hover:border-destructive/40 text-xs h-8"
            >
              <LogOut size={12} className="mr-1.5" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <div className="overflow-x-auto -mx-1 px-1">
            <TabsList
              className="bg-white border border-[oklch(90%_0.01_80)] shadow-warm h-auto p-1 gap-0.5 flex w-max"
              data-ocid="admin.tabs"
            >
              {[
                { value: "overview", label: "Overview" },
                {
                  value: "donations",
                  label: `Donations (${donations.length})`,
                },
                {
                  value: "contacts",
                  label: `Messages (${contacts.length})`,
                },
                {
                  value: "campaigns",
                  label: `Campaigns (${campaigns.length})`,
                },
                { value: "site-content", label: "Site Content" },
                {
                  value: "testimonials",
                  label: `Testimonials (${testimonials.length})`,
                },
                {
                  value: "partners",
                  label: `Partners (${partners.length})`,
                },
                {
                  value: "children",
                  label: `Children (${children.length})`,
                },
              ].map(({ value, label }) => {
                const Icon = TAB_ICONS[value];
                return (
                  <TabsTrigger
                    key={value}
                    value={value}
                    data-ocid={`admin.${value.replace("-", "_")}.tab`}
                    className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg data-[state=active]:bg-[oklch(42%_0.12_195)] data-[state=active]:text-white data-[state=active]:shadow-sm transition-all whitespace-nowrap"
                  >
                    <Icon size={13} />
                    {label}
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </div>

          <TabsContent value="overview" className="mt-0">
            <OverviewTab
              donations={donations}
              contacts={contacts}
              campaigns={campaigns}
            />
          </TabsContent>

          <TabsContent value="donations" className="mt-0">
            <DonationsTab
              donations={donations}
              campaigns={campaigns}
              onDonationsChange={setDonations}
            />
          </TabsContent>

          <TabsContent value="contacts" className="mt-0">
            <ContactsTab contacts={contacts} onContactsChange={setContacts} />
          </TabsContent>

          <TabsContent value="campaigns" className="mt-0">
            <CampaignsTab
              campaigns={campaigns}
              onCampaignsChange={setCampaigns}
            />
          </TabsContent>

          <TabsContent value="site-content" className="mt-0">
            <SiteContentTab
              content={siteContent}
              onContentChange={setSiteContent}
            />
          </TabsContent>

          <TabsContent value="testimonials" className="mt-0">
            <TestimonialsTab
              testimonials={testimonials}
              onTestimonialsChange={setTestimonials}
            />
          </TabsContent>

          <TabsContent value="partners" className="mt-0">
            <PartnersTab partners={partners} onPartnersChange={setPartners} />
          </TabsContent>

          <TabsContent value="children" className="mt-0">
            <ChildrenTab
              childProfiles={children}
              onChildrenChange={setChildren}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
