import { Button } from "@/components/ui/button";
import { Globe, Heart, Menu, Shield, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";
import { SiFacebook, SiInstagram, SiX, SiYoutube } from "react-icons/si";
import { useAdminAuth } from "../hooks/useAdminAuth";
import { AdminLoginModal } from "./AdminLoginModal";

const SOCIAL_LINKS = [
  {
    icon: SiFacebook,
    label: "Facebook",
    href: "https://www.facebook.com/childrenandyouthministryindia/",
  },
  {
    icon: SiYoutube,
    label: "YouTube",
    href: "https://www.youtube.com/@sundayschoolministry8198",
  },
  {
    icon: SiX,
    label: "X / Twitter",
    href: "https://x.com",
  },
  {
    icon: SiInstagram,
    label: "Instagram",
    href: "https://instagram.com",
  },
  {
    icon: Globe,
    label: "Website",
    href: "https://cymichildrenhome.org",
  },
];

interface NavBarProps {
  onNavigate: (section: string) => void;
  currentSection?: string;
  showAdmin?: boolean;
  onAdminClick?: () => void;
}

const NAV_LINKS = [
  { label: "Home", section: "home" },
  { label: "About", section: "about" },
  { label: "Campaigns", section: "campaigns" },
  { label: "Donate", section: "donate" },
  { label: "Impact", section: "impact" },
  { label: "Contact", section: "contact" },
];

export function NavBar({
  onNavigate,
  currentSection,
  onAdminClick,
}: NavBarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const { isAdmin, logout } = useAdminAuth();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (section: string) => {
    onNavigate(section);
    setMobileOpen(false);
  };

  const handleLoginSuccess = () => {
    setLoginModalOpen(false);
    onAdminClick?.();
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/96 backdrop-blur-md shadow-warm"
            : "bg-transparent"
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <button
              type="button"
              onClick={() => handleNavClick("home")}
              className="flex items-center gap-3 group"
              data-ocid="nav.home.link"
            >
              <img
                src="/assets/uploads/bbbb.-2--1.jpg"
                alt="CYMI Logo"
                className="w-10 h-10 object-contain rounded-full"
              />
              <div className="flex flex-col leading-tight">
                <span
                  className={`font-display font-bold text-lg leading-tight transition-colors duration-300 ${
                    scrolled ? "text-[oklch(18%_0.025_60)]" : "text-white"
                  }`}
                >
                  CYMI
                </span>
                <span
                  className={`text-xs font-body transition-colors duration-300 ${
                    scrolled ? "text-[oklch(50%_0.02_60)]" : "text-white/80"
                  }`}
                >
                  Children Home
                </span>
              </div>
            </button>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.section}
                  type="button"
                  onClick={() => handleNavClick(link.section)}
                  data-ocid={`nav.${link.section}.link`}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                    currentSection === link.section
                      ? scrolled
                        ? "text-[oklch(42%_0.12_195)] bg-[oklch(42%_0.12_195_/_0.08)]"
                        : "text-white bg-white/20"
                      : scrolled
                        ? "text-[oklch(40%_0.02_60)] hover:text-[oklch(18%_0.025_60)] hover:bg-[oklch(95%_0.008_80)]"
                        : "text-white/90 hover:text-white hover:bg-white/15"
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* Desktop Actions */}
            <div className="hidden lg:flex items-center gap-3">
              {isAdmin && (
                <button
                  type="button"
                  onClick={onAdminClick}
                  data-ocid="nav.admin.link"
                  className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
                    scrolled
                      ? "text-[oklch(42%_0.12_195)] hover:text-[oklch(35%_0.12_195)]"
                      : "text-white/90 hover:text-white"
                  }`}
                >
                  <Shield size={14} />
                  Admin
                </button>
              )}
              {isAdmin ? (
                <button
                  type="button"
                  onClick={logout}
                  className={`text-sm font-medium transition-colors ${
                    scrolled
                      ? "text-[oklch(50%_0.02_60)] hover:text-[oklch(18%_0.025_60)]"
                      : "text-white/70 hover:text-white"
                  }`}
                >
                  Sign Out
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setLoginModalOpen(true)}
                  data-ocid="nav.admin.link"
                  className={`text-xs font-medium transition-colors ${
                    scrolled
                      ? "text-[oklch(55%_0.02_60)] hover:text-[oklch(42%_0.12_195)]"
                      : "text-white/60 hover:text-white"
                  }`}
                >
                  Admin Login
                </button>
              )}

              {/* Social Icons — desktop */}
              <div
                className={`flex items-center gap-1 pl-2 border-l transition-colors duration-300 ${
                  scrolled ? "border-[oklch(85%_0.01_60)]" : "border-white/25"
                }`}
              >
                {SOCIAL_LINKS.map((s) => {
                  const Icon = s.icon;
                  return (
                    <a
                      key={s.label}
                      href={s.href}
                      aria-label={s.label}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-ocid={`nav.social.${s.label.toLowerCase().split(" ")[0]}.link`}
                      className={`w-7 h-7 rounded-md flex items-center justify-center transition-all duration-200 ${
                        scrolled
                          ? "text-[oklch(55%_0.02_60)] hover:text-[oklch(25%_0.03_60)] hover:bg-[oklch(93%_0.008_80)]"
                          : "text-white/60 hover:text-white hover:bg-white/15"
                      }`}
                    >
                      <Icon size={14} />
                    </a>
                  );
                })}
              </div>

              <Button
                type="button"
                onClick={() => handleNavClick("donate")}
                data-ocid="nav.donate.button"
                className="bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white font-semibold px-5 py-2 rounded-full shadow-warm transition-all duration-200 hover:shadow-warm-lg"
              >
                <Heart size={14} className="mr-2 fill-current" />
                Donate Now
              </Button>
            </div>

            {/* Mobile toggle */}
            <button
              type="button"
              onClick={() => setMobileOpen(!mobileOpen)}
              className={`lg:hidden p-2 rounded-md transition-colors ${
                scrolled ? "text-foreground" : "text-white"
              }`}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="lg:hidden bg-white border-t border-border overflow-hidden shadow-warm-lg"
            >
              <div className="px-4 py-4 flex flex-col gap-1">
                {NAV_LINKS.map((link) => (
                  <button
                    key={link.section}
                    type="button"
                    onClick={() => handleNavClick(link.section)}
                    data-ocid={`nav.${link.section}.link`}
                    className={`w-full text-left px-4 py-2.5 rounded-md text-sm font-medium transition-colors ${
                      currentSection === link.section
                        ? "text-[oklch(42%_0.12_195)] bg-[oklch(42%_0.12_195_/_0.08)]"
                        : "text-[oklch(40%_0.02_60)] hover:text-foreground hover:bg-muted"
                    }`}
                  >
                    {link.label}
                  </button>
                ))}
                <div className="pt-3 pb-1 px-2 flex flex-col gap-2 border-t border-border mt-2">
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        onAdminClick?.();
                        setMobileOpen(false);
                      }}
                      data-ocid="nav.admin.link"
                      className="flex items-center gap-2 text-sm font-medium text-[oklch(42%_0.12_195)]"
                    >
                      <Shield size={14} />
                      Admin Dashboard
                    </button>
                  )}
                  {!isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setLoginModalOpen(true);
                        setMobileOpen(false);
                      }}
                      className="text-sm text-muted-foreground text-left"
                    >
                      Admin Login
                    </button>
                  )}
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={logout}
                      className="text-sm text-muted-foreground text-left"
                    >
                      Sign Out
                    </button>
                  )}

                  {/* Social Icons — mobile */}
                  <div className="flex items-center gap-2 py-1">
                    {SOCIAL_LINKS.map((s) => {
                      const Icon = s.icon;
                      return (
                        <a
                          key={s.label}
                          href={s.href}
                          aria-label={s.label}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-ocid={`nav.mobile.social.${s.label.toLowerCase().split(" ")[0]}.link`}
                          className="w-8 h-8 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200"
                        >
                          <Icon size={15} />
                        </a>
                      );
                    })}
                  </div>

                  <Button
                    type="button"
                    onClick={() => handleNavClick("donate")}
                    data-ocid="nav.donate.button"
                    className="w-full bg-[oklch(42%_0.12_195)] hover:bg-[oklch(35%_0.12_195)] text-white rounded-full"
                  >
                    <Heart size={14} className="mr-2 fill-current" />
                    Donate Now
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <AdminLoginModal
        open={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />
    </>
  );
}
