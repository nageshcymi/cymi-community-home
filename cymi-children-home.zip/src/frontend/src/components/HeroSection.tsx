import { Button } from "@/components/ui/button";
import { ChevronDown, Heart, Smartphone } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { type SiteContent, getInitialSiteContent } from "../lib/adminData";

interface HeroSectionProps {
  onDonate: () => void;
  onLearnMore: () => void;
}

export function HeroSection({ onDonate, onLearnMore }: HeroSectionProps) {
  const [content, setContent] = useState<SiteContent>(getInitialSiteContent);

  useEffect(() => {
    const handleUpdate = () => setContent(getInitialSiteContent());
    window.addEventListener("cymi_site_content_updated", handleUpdate);
    return () =>
      window.removeEventListener("cymi_site_content_updated", handleUpdate);
  }, []);

  const trustIndicators = [
    content.heroTrust1,
    content.heroTrust2,
    content.heroTrust3,
  ];

  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('/assets/generated/cymi-hero-bg.dim_1200x600.jpg')",
        }}
      />

      {/* Warm overlay gradient */}
      <div className="hero-overlay absolute inset-0" />

      {/* Subtle warm glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 50% at 50% 60%, oklch(75% 0.16 75 / 0.12) 0%, transparent 70%)",
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
        {/* Eyebrow badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/15 backdrop-blur-sm border border-white/25 text-xs font-semibold text-white mb-8 tracking-wider uppercase"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[oklch(75%_0.16_75)] animate-pulse" />
          Registered NGO · India
        </motion.div>

        {/* Main Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display font-bold text-4xl sm:text-5xl lg:text-7xl leading-[1.1] tracking-tight mb-6 text-white"
        >
          {content.heroHeadline}
        </motion.h1>

        {/* Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-white/85 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed font-body"
        >
          {content.heroTagline}
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Button
            size="lg"
            data-ocid="hero.primary_button"
            onClick={onDonate}
            className="bg-[oklch(75%_0.16_75)] hover:bg-[oklch(68%_0.16_75)] text-[oklch(18%_0.025_60)] font-bold text-base px-8 py-6 rounded-full shadow-gold transition-all duration-300 group"
          >
            <Heart size={18} className="mr-2 fill-current" />
            Donate Now
          </Button>

          <Button
            size="lg"
            data-ocid="hero.upi_button"
            onClick={() =>
              document
                .getElementById("donate")
                ?.scrollIntoView({ behavior: "smooth" })
            }
            className="font-bold text-base px-8 py-6 rounded-full shadow-lg transition-all duration-300 text-white"
            style={{
              background:
                "linear-gradient(135deg, oklch(45% 0.14 165) 0%, oklch(55% 0.16 175) 100%)",
            }}
          >
            <Smartphone size={18} className="mr-2" />
            Pay via UPI
          </Button>

          <Button
            size="lg"
            variant="outline"
            data-ocid="hero.secondary_button"
            onClick={onLearnMore}
            className="border-white/50 text-white hover:bg-white/15 hover:border-white/70 font-semibold text-base px-8 py-6 rounded-full backdrop-blur-sm transition-all duration-300"
          >
            Learn More
          </Button>
        </motion.div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.55 }}
          className="mt-16 flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-white/65"
        >
          {trustIndicators.map((text) => (
            <span key={text} className="flex items-center gap-2 font-body">
              <span className="w-1.5 h-1.5 rounded-full bg-[oklch(75%_0.16_75)]" />
              {text}
            </span>
          ))}
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.button
        type="button"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        onClick={onLearnMore}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/50 hover:text-white/80 transition-colors"
        aria-label="Scroll down"
      >
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{
            duration: 1.5,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        >
          <ChevronDown size={22} />
        </motion.div>
      </motion.button>
    </section>
  );
}
