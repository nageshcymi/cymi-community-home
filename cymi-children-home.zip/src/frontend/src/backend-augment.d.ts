// This file augments the backendInterface and Backend class to include
// authorization methods added by the Caffeine authorization component,
// plus NGO-specific backend methods.
import type { Principal } from "@icp-sdk/core/principal";

declare module "./backend" {
  interface backendInterface {
    // Authorization methods
    _initializeAccessControlWithSecret(secret: string): Promise<void>;
    getCallerUserRole(): Promise<
      { __kind__: "admin" } | { __kind__: "user" } | { __kind__: "guest" }
    >;
    isCallerAdmin(): Promise<boolean>;
    assignCallerUserRole(
      user: Principal,
      role:
        | { __kind__: "admin" }
        | { __kind__: "user" }
        | { __kind__: "guest" },
    ): Promise<void>;

    // Campaign methods
    getCampaigns(): Promise<
      Array<{
        id: bigint;
        name: string;
        description: string;
        goalAmount: bigint;
      }>
    >;
    getCampaignProgress(): Promise<
      Array<{
        campaignId: bigint;
        campaignName: string;
        totalRaised: bigint;
        goalAmount: bigint;
      }>
    >;

    // Stats methods
    getStats(): Promise<{
      totalDonations: bigint;
      totalAmountRaised: bigint;
      totalContacts: bigint;
    }>;

    // Donation methods
    getDonations(): Promise<
      Array<{
        id: bigint;
        donorName: string;
        email: string;
        amount: bigint;
        message: string;
        campaignId: bigint;
        timestamp: bigint;
      }>
    >;
    submitDonation(
      donorName: string,
      email: string,
      amount: bigint,
      message: string,
      campaignId: bigint,
    ): Promise<void>;

    // Contact methods
    getContacts(): Promise<
      Array<{
        id: bigint;
        name: string;
        email: string;
        message: string;
        timestamp: bigint;
      }>
    >;
    submitContact(name: string, email: string, message: string): Promise<void>;
  }

  // Augment Backend class to satisfy the extended interface
  interface Backend {
    _initializeAccessControlWithSecret(secret: string): Promise<void>;
    getCallerUserRole(): Promise<
      { __kind__: "admin" } | { __kind__: "user" } | { __kind__: "guest" }
    >;
    isCallerAdmin(): Promise<boolean>;
    assignCallerUserRole(
      user: Principal,
      role:
        | { __kind__: "admin" }
        | { __kind__: "user" }
        | { __kind__: "guest" },
    ): Promise<void>;

    getCampaigns(): Promise<
      Array<{
        id: bigint;
        name: string;
        description: string;
        goalAmount: bigint;
      }>
    >;
    getCampaignProgress(): Promise<
      Array<{
        campaignId: bigint;
        campaignName: string;
        totalRaised: bigint;
        goalAmount: bigint;
      }>
    >;
    getStats(): Promise<{
      totalDonations: bigint;
      totalAmountRaised: bigint;
      totalContacts: bigint;
    }>;
    getDonations(): Promise<
      Array<{
        id: bigint;
        donorName: string;
        email: string;
        amount: bigint;
        message: string;
        campaignId: bigint;
        timestamp: bigint;
      }>
    >;
    submitDonation(
      donorName: string,
      email: string,
      amount: bigint,
      message: string,
      campaignId: bigint,
    ): Promise<void>;
    getContacts(): Promise<
      Array<{
        id: bigint;
        name: string;
        email: string;
        message: string;
        timestamp: bigint;
      }>
    >;
    submitContact(name: string, email: string, message: string): Promise<void>;
  }
}
