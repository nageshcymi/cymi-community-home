import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useActor } from "./useActor";

// ── Types ──────────────────────────────────────────────────

export interface Campaign {
  id: bigint;
  name: string;
  description: string;
  goalAmount: bigint;
}

export interface CampaignProgress {
  campaignId: bigint;
  campaignName: string;
  totalRaised: bigint;
  goalAmount: bigint;
}

export interface Donation {
  id: bigint;
  donorName: string;
  email: string;
  amount: bigint;
  message: string;
  campaignId: bigint;
  timestamp: bigint;
}

export interface Contact {
  id: bigint;
  name: string;
  email: string;
  message: string;
  timestamp: bigint;
}

export interface Stats {
  totalDonations: bigint;
  totalAmountRaised: bigint;
  totalContacts: bigint;
}

// ── Queries ────────────────────────────────────────────────

export function useCampaigns() {
  const { actor, isFetching } = useActor();
  return useQuery<Campaign[]>({
    queryKey: ["campaigns"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getCampaigns();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useCampaignProgress() {
  const { actor, isFetching } = useActor();
  return useQuery<CampaignProgress[]>({
    queryKey: ["campaignProgress"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getCampaignProgress();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStats() {
  const { actor, isFetching } = useActor();
  return useQuery<Stats>({
    queryKey: ["stats"],
    queryFn: async () => {
      if (!actor)
        return { totalDonations: 0n, totalAmountRaised: 0n, totalContacts: 0n };
      return actor.getStats();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useDonations() {
  const { actor, isFetching } = useActor();
  return useQuery<Donation[]>({
    queryKey: ["donations"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getDonations();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useContacts() {
  const { actor, isFetching } = useActor();
  return useQuery<Contact[]>({
    queryKey: ["contacts"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getContacts();
    },
    enabled: !!actor && !isFetching,
  });
}

// ── Mutations ──────────────────────────────────────────────

export function useSubmitDonation() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      donorName,
      email,
      amount,
      message,
      campaignId,
    }: {
      donorName: string;
      email: string;
      amount: bigint;
      message: string;
      campaignId: bigint;
    }) => {
      if (!actor) throw new Error("Not connected to backend");
      return actor.submitDonation(
        donorName,
        email,
        amount,
        message,
        campaignId,
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["donations"] });
      queryClient.invalidateQueries({ queryKey: ["campaignProgress"] });
      queryClient.invalidateQueries({ queryKey: ["stats"] });
    },
  });
}

export function useSubmitContact() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      name,
      email,
      message,
    }: {
      name: string;
      email: string;
      message: string;
    }) => {
      if (!actor) throw new Error("Not connected to backend");
      return actor.submitContact(name, email, message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      queryClient.invalidateQueries({ queryKey: ["stats"] });
    },
  });
}
