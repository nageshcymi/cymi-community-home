import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "admin_authenticated";
const ADMIN_ID = "CYMI";
const ADMIN_PASSWORD = "CYMI@123n";

export function useAdminAuth() {
  const [isAdmin, setIsAdmin] = useState<boolean>(
    () => sessionStorage.getItem(STORAGE_KEY) === "true",
  );

  useEffect(() => {
    const handler = () => {
      setIsAdmin(sessionStorage.getItem(STORAGE_KEY) === "true");
    };
    window.addEventListener("admin-auth-change", handler);
    return () => window.removeEventListener("admin-auth-change", handler);
  }, []);

  const login = useCallback((id: string, password: string): boolean => {
    if (id === ADMIN_ID && password === ADMIN_PASSWORD) {
      sessionStorage.setItem(STORAGE_KEY, "true");
      setIsAdmin(true);
      window.dispatchEvent(new Event("admin-auth-change"));
      return true;
    }
    return false;
  }, []);

  const logout = useCallback((): void => {
    sessionStorage.removeItem(STORAGE_KEY);
    setIsAdmin(false);
    window.dispatchEvent(new Event("admin-auth-change"));
  }, []);

  return { isAdmin, login, logout };
}
