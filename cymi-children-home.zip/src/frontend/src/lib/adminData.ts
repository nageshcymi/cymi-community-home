// ── Types ──────────────────────────────────────────────────

export interface LocalDonation {
  id: string;
  donorName: string;
  email: string;
  amount: number; // in cents
  campaignId: number;
  message: string;
  timestamp: number; // ms
}

export interface LocalContact {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: number; // ms
}

export interface LocalCampaign {
  id: number;
  name: string;
  description: string;
  goalAmount: number; // in USD
}

export interface SiteContent {
  // Hero Section
  heroHeadline: string;
  heroTagline: string;
  heroTrust1: string;
  heroTrust2: string;
  heroTrust3: string;
  // About Section
  aboutBio: string;
  aboutSubheading: string;
  aboutFoundedYear: string;
  aboutLocation: string;
  aboutStory1: string;
  aboutStory2: string;
  // Impact Section
  impactQuote: string;
  impactQuoteAuthor: string;
  // Stats
  childrenCount: string;
  yearsOfService: string;
  donorsCount: string;
  graduationRate: string;
  // Contact
  contactEmail: string;
  contactPhone: string;
  contactAddress: string;
  // Footer
  footerTagline: string;
  footerNgoNote: string;
}

// ── Keys ───────────────────────────────────────────────────

export const LS_DONATIONS = "cymi_donations";
export const LS_CONTACTS = "cymi_contacts";
export const LS_CAMPAIGNS = "cymi_campaigns";
export const LS_SITE_CONTENT = "cymi_site_content";

// ── Seed Data ──────────────────────────────────────────────

export const SEED_CAMPAIGNS: LocalCampaign[] = [
  {
    id: 1,
    name: "Education Fund 2026",
    description:
      "Fund school fees, uniforms, books, and learning materials for 150 children.",
    goalAmount: 15000,
  },
  {
    id: 2,
    name: "Medical Care & Nutrition",
    description:
      "Provide medical check-ups, vaccinations, dental care, and balanced meals every day.",
    goalAmount: 25000,
  },
  {
    id: 3,
    name: "New Dormitory Building",
    description:
      "Construct a new dormitory to accommodate 50 more children on the waiting list.",
    goalAmount: 50000,
  },
];

export const SEED_DONATIONS: LocalDonation[] = [
  {
    id: "dummy-001",
    donorName: "Rahul Sharma",
    email: "rahul.sharma@example.com",
    amount: 5000, // $50.00
    campaignId: 1,
    message: "Keep up the great work!",
    timestamp: Date.now(),
  },
];

export const SEED_CONTACTS: LocalContact[] = [
  {
    id: "dummy-c001",
    name: "Priya Menon",
    email: "priya.menon@example.com",
    message: "I would love to volunteer. Please contact me.",
    timestamp: Date.now(),
  },
];

export const SEED_SITE_CONTENT: SiteContent = {
  heroHeadline: "Every Child Deserves a Future",
  heroTagline:
    "CYMI Children Home provides love, education, and care to orphaned and vulnerable children — giving every child the chance to thrive.",
  heroTrust1: "150+ Children in Our Care",
  heroTrust2: "10 Years of Service",
  heroTrust3: "500+ Donors Worldwide",
  aboutBio:
    "Children and Youth Ministry that is active and planning ahead has a great opportunity for activities that assist the church in spreading the gospel.",
  aboutSubheading: "Transforming Lives, One Child at a Time",
  aboutFoundedYear: "2015",
  aboutLocation: "Karnataka, India",
  aboutStory1:
    "Founded in 2015, CYMI Children Home was born from a simple belief: every child deserves safety, love, and opportunity — regardless of their circumstances. We provide holistic care to orphaned and vulnerable children, giving them a nurturing home, quality education, and a community that supports them through life.",
  aboutStory2:
    "Over a decade, we have grown from sheltering 12 children to supporting over 150 in our care, with alumni going on to university, professional careers, and giving back to their communities. Our work is powered by compassionate donors and volunteers from around the world.",
  impactQuote:
    '"We have seen children grow from hopelessness to becoming doctors, teachers, and leaders."',
  impactQuoteAuthor: "— Director, CYMI Children Home",
  childrenCount: "150+",
  yearsOfService: "10",
  donorsCount: "500+",
  graduationRate: "95%",
  contactEmail: "childrenandyouthministry@gmail.com",
  contactPhone: "+91 9997621079",
  contactAddress:
    "Bhovi Colony, Jagaluru, Huchangipura, Karnataka 577513, India",
  footerTagline:
    "Transforming Lives, One Child at a Time. Providing love, education, and care to orphaned and vulnerable children.",
  footerNgoNote: "Registered Non-Governmental Organisation",
};

// ── Helpers ────────────────────────────────────────────────

function lsGet<T>(key: string, seed: T): T {
  try {
    const item = window.localStorage.getItem(key);
    if (item) return JSON.parse(item) as T;
    window.localStorage.setItem(key, JSON.stringify(seed));
    return seed;
  } catch {
    return seed;
  }
}

export function getInitialDonations(): LocalDonation[] {
  return lsGet(LS_DONATIONS, SEED_DONATIONS);
}

export function getInitialContacts(): LocalContact[] {
  return lsGet(LS_CONTACTS, SEED_CONTACTS);
}

export function getInitialCampaigns(): LocalCampaign[] {
  return lsGet(LS_CAMPAIGNS, SEED_CAMPAIGNS);
}

export function getInitialSiteContent(): SiteContent {
  try {
    const item = window.localStorage.getItem(LS_SITE_CONTENT);
    if (item) {
      // Merge stored data with seed to fill any missing new fields
      const stored = JSON.parse(item) as Partial<SiteContent>;
      return { ...SEED_SITE_CONTENT, ...stored };
    }
    window.localStorage.setItem(
      LS_SITE_CONTENT,
      JSON.stringify(SEED_SITE_CONTENT),
    );
    return SEED_SITE_CONTENT;
  } catch {
    return SEED_SITE_CONTENT;
  }
}

export function saveDonation(donation: LocalDonation): void {
  try {
    const existing = getInitialDonations();
    const updated = [...existing, donation];
    window.localStorage.setItem(LS_DONATIONS, JSON.stringify(updated));
  } catch {
    // Silently fail
  }
}

export function saveContact(contact: LocalContact): void {
  try {
    const existing = getInitialContacts();
    const updated = [...existing, contact];
    window.localStorage.setItem(LS_CONTACTS, JSON.stringify(updated));
  } catch {
    // Silently fail
  }
}

export function centsToDollars(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function formatDate(ms: number): string {
  return new Date(ms).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// ── Partner & Testimonial Types ─────────────────────────────

export interface LocalPartner {
  id: string;
  name: string;
  description: string;
  logoInitials: string; // e.g. "UN", "WV" — used as avatar when no photo
  logoUrl: string; // empty string if no photo
  website: string; // optional URL
}

export interface LocalTestimonial {
  id: string;
  name: string;
  role: string;
  quote: string;
  avatarInitials: string;
  rating: number; // 1-5
}

// ── Additional LS Keys ──────────────────────────────────────

export const LS_PARTNERS = "cymi_partners";
export const LS_TESTIMONIALS = "cymi_testimonials";

// ── Partner & Testimonial Seed Data ────────────────────────

export const SEED_PARTNERS: LocalPartner[] = [
  {
    id: "p1",
    name: "World Vision",
    description:
      "Global humanitarian organisation partnering to support child welfare programs.",
    logoInitials: "WV",
    logoUrl: "",
    website: "https://www.worldvision.org",
  },
  {
    id: "p2",
    name: "UNICEF India",
    description:
      "Working together to ensure every child's right to education and health.",
    logoInitials: "UN",
    logoUrl: "",
    website: "https://www.unicef.org/india",
  },
  {
    id: "p3",
    name: "Compassion International",
    description:
      "Child development organisation releasing children from poverty in Jesus' name.",
    logoInitials: "CI",
    logoUrl: "",
    website: "https://www.compassion.com",
  },
];

export const SEED_TESTIMONIALS: LocalTestimonial[] = [
  {
    id: "t1",
    name: "Sarah M.",
    role: "Monthly Donor, United Kingdom",
    quote:
      "I started donating $25 a month two years ago. Knowing that my small contribution helps a child eat, sleep safely, and go to school fills my heart every single day. CYMI is transparent, responsive, and genuinely makes a difference.",
    avatarInitials: "SM",
    rating: 5,
  },
  {
    id: "t2",
    name: "John K.",
    role: "Corporate Sponsor, United States",
    quote:
      "Our company chose CYMI for our CSR initiative and we have never looked back. The regular impact reports, the stories from the children, and the integrity of their leadership make this the most rewarding partnership we have ever had.",
    avatarInitials: "JK",
    rating: 5,
  },
  {
    id: "t3",
    name: "Grace O.",
    role: "Volunteer & Donor, Kenya",
    quote:
      "I volunteered at CYMI for a month and was moved to tears by the love in that place. The staff treat every child like family. When I left, I set up a standing donation because I know every shilling goes directly to the children.",
    avatarInitials: "GO",
    rating: 5,
  },
];

// ── Partner & Testimonial Helpers ──────────────────────────

export function getInitialPartners(): LocalPartner[] {
  return lsGet(LS_PARTNERS, SEED_PARTNERS);
}

export function getInitialTestimonials(): LocalTestimonial[] {
  return lsGet(LS_TESTIMONIALS, SEED_TESTIMONIALS);
}

// ── Children Profile Types ──────────────────────────────────

export interface LocalChild {
  id: string;
  name: string;
  age: string; // e.g. "8 years"
  story: string; // short quote / testimonial
  photoUrl: string; // empty string if none
  photoInitials: string; // 2-char fallback avatar
  program: string; // e.g. "Education Fund"
}

export const LS_CHILDREN = "cymi_children";

export const SEED_CHILDREN: LocalChild[] = [
  {
    id: "ch1",
    name: "Arjun",
    age: "9 years",
    story:
      "I love going to school and learning maths. One day I want to be an engineer and build bridges.",
    photoUrl: "/assets/generated/child-arjun.dim_400x400.jpg",
    photoInitials: "AR",
    program: "Education Fund 2026",
  },
  {
    id: "ch2",
    name: "Preethi",
    age: "7 years",
    story:
      "CYMI gave me a safe home and kind teachers. I draw pictures every day and dream of becoming an artist.",
    photoUrl: "/assets/generated/child-preethi.dim_400x400.jpg",
    photoInitials: "PR",
    program: "Medical Care & Nutrition",
  },
  {
    id: "ch3",
    name: "Samuel",
    age: "11 years",
    story:
      "Before CYMI I had never eaten three meals a day. Now I am healthy, happy, and top of my class.",
    photoUrl: "/assets/generated/child-samuel.dim_400x400.jpg",
    photoInitials: "SA",
    program: "New Dormitory Building",
  },
];

export function getInitialChildren(): LocalChild[] {
  const stored = lsGet(LS_CHILDREN, SEED_CHILDREN);
  // Backfill photos for seed children if they have none
  return stored.map((c) => {
    const seed = SEED_CHILDREN.find((s) => s.id === c.id);
    if (seed && !c.photoUrl && seed.photoUrl)
      return { ...c, photoUrl: seed.photoUrl };
    return c;
  });
}
